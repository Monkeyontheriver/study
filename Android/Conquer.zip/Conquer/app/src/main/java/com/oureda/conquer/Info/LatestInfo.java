package com.oureda.conquer.Info;

/**
 * Created by 刘丰恺 on 2015/8/10.
 */
public class LatestInfo {
    private int Latest_Img;
    private String Latest_Id;
    private String Latest_TalkLog;
    private String Latest_CreditLine;
    private String Latest_HaveWatched;
    private String Latest_TalkIt;
    private String Latest_LikeIt;
    private String Latest_Time;
    private boolean Latest_IfTouched;

    public LatestInfo(int img,String id,String talklog,String creditline,String hacewatched,String time,String talkit,String likeit,boolean touched){
        this.Latest_Img = img;
        this.Latest_Id = id;
        this.Latest_CreditLine = creditline;
        this.Latest_HaveWatched = hacewatched;
        this.Latest_TalkIt = talkit;
        this.Latest_TalkLog = talklog;
        this.Latest_LikeIt = likeit;
        this.Latest_Time = time;
        this.Latest_IfTouched = touched;
    }

    public int getLatest_Img() {
        return Latest_Img;
    }

    public String getLatest_Time() {
        return Latest_Time;
    }

    public boolean isLatest_IfTouched() {
        return Latest_IfTouched;
    }

    public String getLatest_Id() {
        return Latest_Id;
    }

    public String getLatest_TalkLog() {
        return Latest_TalkLog;
    }

    public String getLatest_CreditLine() {
        return Latest_CreditLine;
    }

    public String getLatest_HaveWatched() {
        return Latest_HaveWatched;
    }

    public String getLatest_TalkIt() {
        return Latest_TalkIt;
    }

    public String getLatest_LikeIt() {
        return Latest_LikeIt;
    }
}
