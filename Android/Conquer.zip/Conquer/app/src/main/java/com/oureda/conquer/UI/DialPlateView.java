package com.oureda.conquer.UI;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.util.AttributeSet;
import android.view.View;

@SuppressLint("DrawAllocation")
public class DialPlateView extends View {

	private int backgroundColor = Color.WHITE;

	private Paint mPaint;
	private int[] colors = { Color.rgb(255, 0, 0), Color.rgb(255, 200, 0),
			Color.rgb(0, 255, 200) };
	private Paint textPaint;

	private RectF recrf;

	private int max;
	private int min;
	private float finished;

	private String durNum = "300";
	private String textJudge = "信用良好";
	private String textJudgeTime = "评估时间：2015-07-13";
	private int judgeTimeColor = Color.parseColor("#acacac");

	private int unitLength;

	private int durColor = colors[0];
	private boolean changeColor = true;

	public DialPlateView(Context context) {
		this(context, null);
	}

	public DialPlateView(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public DialPlateView(Context context, AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		initData();
	}

	private void initData() {
		mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
	}

	/**
	 * 设置最小值
	 *
	 * @param min
	 */
	public void setMin(int min) {
		this.min = min;
		this.unitLength = (this.max - min) / 6;
		durNum = min + "";
		invalidate();
	}

	/**
	 * 获取最小值
	 *
	 * @return
	 */
	public int getMin() {
		return min;
	}

	/**
	 * 设置最大值
	 *
	 * @param max
	 */
	public void setMax(int max) {
		this.max = max;
		this.unitLength = (this.max - min) / 6;
	}

	/**
	 * 获取最大值
	 *
	 * @return
	 */
	public int getMax() {
		return max;
	}

	/**
	 * 设置评价文字
	 *
	 * @param judge
	 */
	public void setTextJudge(String judge) {
		this.textJudge = judge;
		invalidate();
	}

	/**
	 * 设置评估时间
	 *
	 * @param judgeTime
	 */
	public void setTextJudgeTime(String judgeTime) {
		this.textJudgeTime = judgeTime;
		invalidate();
	}

	/**
	 * 设置评估时间的颜色（同时也是刻度盘的颜色）
	 *
	 * @param color
	 */
	public void setJudgeTimeColor(int color) {
		this.judgeTimeColor = color;
		invalidate();
	}

	/**
	 * 设置当前进度
	 *
	 * @param progress
	 * @return
	 */
	public boolean setProgress(int progress) {
		if (progress <= max && progress >= min) {
			finished = (progress - min) * 1.0f / (max - min);
			if (finished >= 0.5f) {
				float i = (finished - 0.5f) * 2;
				durColor = Color.rgb((int) (255 * (1 - i)),
						(int) (200 + 55 * i), (int) (200 * i));
			} else {
				durColor = Color.rgb(255, (int) (200 * finished * 2), 0);
			}
			durNum = progress + "";
			invalidate();
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 设置环形进度条的颜色
	 *
	 * @param changeColor
	 *            true为渐变色 false为红色
	 */
	public void setProgressColorStatus(boolean changeColor) {
		this.changeColor = changeColor;
	}

	@Override
	public void setBackgroundColor(int color) {
		super.setBackgroundColor(color);
		backgroundColor = color;
	}

	private int getBackgroundColor() {
		return backgroundColor;
	}

	@Override
	protected void onDraw(Canvas canvas) {
		canvas.drawColor(Color.parseColor("#00000000"));
		//
		float[] d = { 0f, 0.18f, 0.55f };
		int margin = dip2px(getContext(), getWidth() * 0.02f);

		Shader sweep = new SweepGradient(canvas.getWidth() / 2,
				canvas.getWidth() / 2, new int[] { colors[0], colors[1],
				colors[2] }, d);
		Matrix localM = new Matrix();
		localM.setRotate(170, canvas.getWidth() / 2, canvas.getWidth() / 2);
		sweep.setLocalMatrix(localM);
		mPaint.setShader(sweep);
		mPaint.setStyle(Paint.Style.STROKE);
		mPaint.setStrokeWidth((canvas.getWidth() - margin * 2) / 10);
		recrf = new RectF(margin, margin, canvas.getWidth() - margin,
				canvas.getWidth() - margin);
		canvas.drawArc(recrf, 170, 200, false, mPaint);

		int marginLine = margin / 3;
		Paint mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		mPaint.setColor(getBackgroundColor());
		mPaint.setStyle(Paint.Style.STROKE);
		mPaint.setStrokeWidth((canvas.getWidth() - margin * 2) / 10);
		recrf = new RectF(margin + marginLine, margin + marginLine,
				canvas.getWidth() - margin - marginLine, canvas.getWidth()
				- margin - marginLine);
		for (int i = 0; i < 7; i++) {
			canvas.drawArc(recrf, 179.5f + 30 * i, 0.5f, false, mPaint);
		}
		mPaint = null;

		textPaint.setColor(durColor);
		textPaint.setTextAlign(Paint.Align.CENTER);
		int textSize = (int) ((canvas.getWidth() - margin * 2) * 0.15);

		textPaint.setTextSize(textSize);
		canvas.drawText(durNum, canvas.getWidth() / 2, canvas.getWidth() / 2
				- textSize, textPaint);

		textPaint.setTextSize(textSize / 2);
		canvas.drawText(textJudge, canvas.getWidth() / 2, canvas.getWidth() / 2
				- textSize / 3, textPaint);

		textPaint.setTextSize(textSize / 4);
		textPaint.setColor(judgeTimeColor);
		canvas.drawText(textJudgeTime, canvas.getWidth() / 2, canvas.getWidth()
				/ 2 + textSize / 4, textPaint);

		// 设置表盘
		recrf = new RectF(margin * 2 + marginLine, margin * 2 + marginLine,
				canvas.getWidth() - margin * 2 - marginLine, canvas.getWidth()
				- margin * 2 - marginLine);
		Path numPath;
		for (int i = 0; i < 7; i++) {
			numPath = new Path();
			numPath.addArc(recrf, 177 + 30 * i, 5);
			canvas.drawTextOnPath((min + i * unitLength) + "", numPath, 0, 0,
					textPaint);
			numPath = null;
		}

		Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
		paint.setColor(getProgressColor(changeColor));
		paint.setStyle(Paint.Style.STROKE);
		paint.setStrokeWidth(marginLine / 3);
		recrf = new RectF(margin * 2 + marginLine * 2, margin * 2 + marginLine
				* 2, canvas.getWidth() - margin * 2 - marginLine * 2,
				canvas.getWidth() - margin * 2 - marginLine * 2);
		canvas.drawArc(recrf, 180f, 180f * finished, false, paint);
		paint.setColor(durColor);
		paint.setStrokeWidth(marginLine / 2);
		if (finished != 0)
			canvas.drawArc(recrf, 180f * (1 + finished) - 0.5f, 1.5f, false,
					paint);
		paint = null;

	}

	private int getProgressColor(boolean changeColor) {
		if (changeColor) {
			return durColor;
		} else {
			return colors[0];
		}
	}

	/**
	 * 根据手机的分辨率从 dp 的单位 转成为 px(像素)
	 */
	private int dip2px(Context context, float dpValue) {
		final float scale = context.getResources().getDisplayMetrics().density;
		return (int) (dpValue * scale + 0.5f);
	}

}
