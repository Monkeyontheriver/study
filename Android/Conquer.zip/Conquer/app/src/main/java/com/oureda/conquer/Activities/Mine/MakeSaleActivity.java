package com.oureda.conquer.Activities.Mine;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.oureda.conquer.R;

import java.io.FileNotFoundException;

//发布拍卖
public class MakeSaleActivity extends Activity implements View.OnClickListener{
    private ImageView Picture;
    private static int SELECT_PICTURE = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_make_sale);
        findViewById(R.id.ms_back).setOnClickListener(this);
        findViewById(R.id.ms_tianjiazhaopian).setOnClickListener(this);
        Picture = (ImageView)findViewById(R.id.ms_picture);
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.ms_back:
                finish();
                break;
            case R.id.ms_tianjiazhaopian:
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("image/*");
                startActivityForResult(Intent.createChooser(intent, "选择图片"), SELECT_PICTURE);
                break;
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == SELECT_PICTURE) {
                //选择图片
                ContentResolver cr = this.getContentResolver();
                Uri uri = data.getData();
                try {
                    Picture.setImageBitmap(BitmapFactory.decodeStream(cr.openInputStream(uri)));
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
