package com.oureda.conquer.Activities.Mine;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.oureda.conquer.Adapter.BankAdapter;
import com.oureda.conquer.Info.BankInfo;
import com.oureda.conquer.R;

import java.util.ArrayList;

//选择银行
public class BankChooseActivity extends Activity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bank_choose);
        ListView BankChooseListView = (ListView)findViewById(R.id.bank_choose_listview);
        ArrayList<BankInfo> arrayList = new ArrayList<>();
        arrayList.add(new BankInfo(R.drawable.logo_gongshang,"工商银行","单笔5万，单日50万，单月无限额"));
        arrayList.add(new BankInfo(R.drawable.logo_guangda,"光大银行","单笔5万，单日5万，单月无限额"));
        arrayList.add(new BankInfo(R.drawable.logo_nognye,"农业银行","单笔5万，单日5万，单月无限额"));
        arrayList.add(new BankInfo(R.drawable.logo_jiaotong,"交通银行","单笔5万，单日50万，单月无限额"));
        arrayList.add(new BankInfo(R.drawable.logo_zhongguo,"中国银行","单笔5万，单日50万，单月无限额"));
        arrayList.add(new BankInfo(R.drawable.logo_jianshe,"建设银行","单笔50万，单日100万，单月无限额"));
        arrayList.add(new BankInfo(R.drawable.logo_zhaoshang,"招商银行","单笔50万，单日100万，单月无限额"));
        arrayList.add(new BankInfo(R.drawable.logo_pingan,"平安银行","单笔10万，单日100万，单月无限额"));
        arrayList.add(new BankInfo(R.drawable.logo_xingye,"兴业银行","单笔50万，单日100万，单月无限额"));
        arrayList.add(new BankInfo(R.drawable.logo_pufa, "浦发银行", "单笔5万，单日5万，单月无限额"));
        BankAdapter bankAdapter = new BankAdapter(this,arrayList);
        BankChooseListView.setAdapter(bankAdapter);
        BankChooseListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(BankChooseActivity.this, AddCreditCardActivity.class);
                String passString = ((TextView) view.findViewById(R.id.bank_title)).getText().toString();
                intent.putExtra("bank", passString);
                setResult(RESULT_OK, intent);
                finish();

            }
        });
        findViewById(R.id.bank_choose_back).setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.bank_choose_back:
                finish();
                break;
        }
    }
}
