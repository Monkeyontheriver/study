package com.oureda.conquer.Info;

/**
 * Created by liufengkai on 15/9/7.
 */
public class MessageInfo {
    private String message_pro;
    private int message_img;
    private String message_time;
    private String message_what;
    private String message_name;
    private int message_color;

    public MessageInfo(String message_pro, int message_img,
                       String message_time, String message_what,
                       String message_name, int message_color) {
        this.message_pro = message_pro;
        this.message_img = message_img;
        this.message_time = message_time;
        this.message_what = message_what;
        this.message_name = message_name;
        this.message_color = message_color;
    }

    public int getMessage_color() {
        return message_color;
    }

    public String getMessage_pro() {
        return message_pro;
    }

    public int getMessage_img() {
        return message_img;
    }

    public String getMessage_time() {
        return message_time;
    }

    public String getMessage_what() {
        return message_what;
    }

    public String getMessage_name() {
        return message_name;
    }
}
