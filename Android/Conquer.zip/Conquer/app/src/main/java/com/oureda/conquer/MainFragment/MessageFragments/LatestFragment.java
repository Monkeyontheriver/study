package com.oureda.conquer.MainFragment.MessageFragments;


import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.oureda.conquer.Adapter.LatestAdapter;
import com.oureda.conquer.Info.LatestInfo;
import com.oureda.conquer.R;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class LatestFragment extends android.support.v4.app.Fragment {
    private View wrapper;
    public static LatestFragment newInstance(){
        return new LatestFragment();
    }

    public LatestFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        this.wrapper =  inflater.inflate(R.layout.fragment_latest, container, false);
        ListView Latest_ListView = (ListView)wrapper.findViewById(R.id.edu_listview);
        ArrayList<LatestInfo> arrayList = new ArrayList<>();
        arrayList.add(new LatestInfo(R.drawable.face1,"某冉","管理费、托管费是怎么收取的？管理费、托管费是怎么收取的？管理费、托管费是怎么收取的？",
                "信用度：680","浏览28次","今天 22:16","4","4",false));
        arrayList.add(new LatestInfo(R.drawable.face2,"李京文","深圳证券账户卡\n" +
                "投资者：可以通过所在地的证券营业部或证券登记机构办理，需提供本人有效身份证件及复印件，委托他人代办的，还需提供代办人身份证及复印件。",
                "信用度：680","浏览28次","今天 22:16","4","4",false));
        arrayList.add(new LatestInfo(R.drawable.face3,"徐采","管理费、托管费是怎么收取的？管理费、托管费是怎么收取的？管理费、托管费是怎么收取的？",
                "信用度：680","浏览28次","今天 22:16","4","4",true));
        arrayList.add(new LatestInfo(R.drawable.face4,"罗洪文","管理费、托管费是怎么收取的？管理费、托管费是怎么收取的？管理费、托管费是怎么收取的？",
                "信用度：680","浏览28次","今天 22:16","4","4",false));
        arrayList.add(new LatestInfo(R.drawable.face5,"常凯申","上海证券账户卡\n" +
                "投资者：可以到上海证券中央登记结算公司在各地的开户代理机构处，办理有关申请开立证券账户手续，带齐有效省份证件和复印件。",
                "信用度：680","浏览28次","今天 22:16","4","4",true));
        arrayList.add(new LatestInfo(R.drawable.face6,"提督","管理费、托管费是怎么收取的？管理费、托管费是怎么收取的？管理费、托管费是怎么收取的？",
                "信用度：680","浏览28次","今天 22:16","4","4",false));
        LatestAdapter latestAdapter = new LatestAdapter(getActivity(),arrayList);
        Latest_ListView.setAdapter(latestAdapter);
        Latest_ListView.setItemsCanFocus(true);
        Latest_ListView.setVerticalScrollBarEnabled(true);
        return wrapper;
    }


}
