package com.oureda.conquer.Info;

/**
 * Created by 刘丰恺 on 2015/8/13.
 */
public class BankInfo {
    private int Bank_img;
    private String  Bank_Title;
    private String  Bank_Text;

    public BankInfo(int img,String title,String text){
        this.Bank_img = img;
        this.Bank_Title = title;
        this.Bank_Text = text;
    }
    public int getBank_img() {
        return Bank_img;
    }

    public String getBank_Title() {
        return Bank_Title;
    }

    public String getBank_Text() {
        return Bank_Text;
    }
}
