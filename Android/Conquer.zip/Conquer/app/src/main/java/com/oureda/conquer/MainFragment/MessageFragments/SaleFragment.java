package com.oureda.conquer.MainFragment.MessageFragments;


import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.oureda.conquer.Adapter.SaleAdapter;
import com.oureda.conquer.Info.SaleInfo;
import com.oureda.conquer.R;
import com.oureda.conquer.Activities.Message.SaleContentActivity;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class SaleFragment extends android.support.v4.app.Fragment {
    private View wrapper;
    public static SaleFragment newInstance(){
        return new SaleFragment();
    }

    public SaleFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        this.wrapper = inflater.inflate(R.layout.fragment_sale, container, false);
        ListView  Sale_ListView = (ListView)wrapper.findViewById(R.id.sale_listview);
        ArrayList<SaleInfo> arrayList = new ArrayList<>();
        arrayList.add(new SaleInfo(R.drawable.face1,"水果蛋糕","￥ 269","起拍价 : ￥ 55","热卖","已结束"));
        arrayList.add(new SaleInfo(R.drawable.face2,"水果蛋糕","￥ 269","起拍价 : ￥ 55","热卖","已结束"));
        arrayList.add(new SaleInfo(R.drawable.face3,"水果蛋糕","￥ 269","起拍价 : ￥ 55","热卖","已结束"));
        arrayList.add(new SaleInfo(R.drawable.face4,"水果蛋糕","￥ 269","起拍价 : ￥ 55","热卖","已结束"));
        arrayList.add(new SaleInfo(R.drawable.face5,"水果蛋糕","￥ 269","起拍价 : ￥ 55","热卖","已结束"));
        arrayList.add(new SaleInfo(R.drawable.face6,"水果蛋糕","￥ 269","起拍价 : ￥ 55","热卖","已结束"));
        arrayList.add(new SaleInfo(R.drawable.face6,"水果蛋糕","￥ 269","起拍价 : ￥ 55","热卖","已结束"));
        SaleAdapter saleAdapter = new SaleAdapter(getActivity(),arrayList);
        Sale_ListView.setAdapter(saleAdapter);
        Sale_ListView.setVerticalScrollBarEnabled(true);
        Sale_ListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(getActivity(), SaleContentActivity.class);
                getActivity().startActivity(intent);
            }
        });
        return wrapper;
    }
}
