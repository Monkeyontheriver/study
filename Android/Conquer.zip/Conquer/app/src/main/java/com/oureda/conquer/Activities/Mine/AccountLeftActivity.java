package com.oureda.conquer.Activities.Mine;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

import com.oureda.conquer.R;

//账户余额
public class AccountLeftActivity extends Activity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_left);
        findViewById(R.id.account_left_back).setOnClickListener(this);
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.account_left_back:
                finish();
                break;
        }
    }
}
