package com.oureda.conquer.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.oureda.conquer.Info.ComLinfo;
import com.oureda.conquer.R;

import java.util.ArrayList;

/**
 * Created by 刘丰恺 on 2015/8/10.
 */
public class ComAdapter extends BaseAdapter {
    private LayoutInflater layoutInflater;
    private Context context;
    private ArrayList<ComLinfo> userList;
    public ComAdapter(Context context,ArrayList<ComLinfo> arrayList){
        this.context = context;
        this.layoutInflater = LayoutInflater.from(context);
        this.userList = arrayList;
    }

    private class ComListView{
        private ImageView Com_Img;
        private TextView Com_Id;
        private TextView Com_Project;
        private TextView Com_DoWhat;
        private TextView Com_Time;
        private TextView Com_First;
        private TextView Com_First_Type;
        private TextView Com_Second;
        private TextView Com_Secone_Type;
        private TextView Com_Third;
        private TextView Com_Third_Type;
    }

    @Override
    public int getCount() {
        return userList.size();
    }

    @Override
    public Object getItem(int i) {
        return userList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ComListView comListView = null;
        if(view == null){
            comListView = new ComListView();
            view = layoutInflater.inflate(R.layout.com_list_item,null);
            comListView.Com_Img = (ImageView)view.findViewById(R.id.com_img);
            comListView.Com_Id = (TextView)view.findViewById(R.id.com_id);
            comListView.Com_Project = (TextView)view.findViewById(R.id.com_project);
            comListView.Com_DoWhat = (TextView)view.findViewById(R.id.com_dowhat);
            comListView.Com_Time = (TextView)view.findViewById(R.id.com_time);
            comListView.Com_First = (TextView)view.findViewById(R.id.com_first);
            comListView.Com_First_Type = (TextView)view.findViewById(R.id.com_first_type);
            comListView.Com_Second = (TextView)view.findViewById(R.id.com_second);
            comListView.Com_Secone_Type = (TextView)view.findViewById(R.id.com_second_type);
            comListView.Com_Third = (TextView)view.findViewById(R.id.com_third);
            comListView.Com_Third_Type = (TextView)view.findViewById(R.id.com_third_type);
            view.setTag(comListView);
        }else {
            comListView = (ComListView)view.getTag();
        }
        ComLinfo comLinfo = userList.get(i);
        comListView.Com_Img.setImageResource(comLinfo.getCom_Img());
        comListView.Com_Id.setText(comLinfo.getCom_Id());
        comListView.Com_Project.setText(comLinfo.getCom_Project());
        comListView.Com_DoWhat.setText(comLinfo.getCom_DoWhat());
        comListView.Com_Time.setText(comLinfo.getCom_Time());
        comListView.Com_First.setText(comLinfo.getCom_First());
        comListView.Com_First_Type.setText(comLinfo.getCom_First_Type());
        comListView.Com_Second.setText(comLinfo.getCom_Second());
        comListView.Com_Secone_Type.setText(comLinfo.getCom_Secone_Type());
        comListView.Com_Third.setText(comLinfo.getCom_Third());
        comListView.Com_Third_Type.setText(comLinfo.getCom_Third_Type());
        return view;
    }
}
