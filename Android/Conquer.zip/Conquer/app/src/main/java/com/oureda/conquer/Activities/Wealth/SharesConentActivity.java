package com.oureda.conquer.Activities.Wealth;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.oureda.conquer.Adapter.FriendsAdapter;
import com.oureda.conquer.Info.FriendsInfo;
import com.oureda.conquer.MainFragment.MoneyFragments.FundFragment;
import com.oureda.conquer.R;
import com.shizhefei.view.indicator.Indicator;
import com.shizhefei.view.indicator.IndicatorViewPager;

import java.util.ArrayList;
//股票子页面
public class SharesConentActivity extends FragmentActivity implements View.OnClickListener{
    private String typecontent;
    private ViewPager Shares_Content_ViewPager;
    private LayoutInflater inflate;
    private IndicatorViewPager indicatorViewPager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shares_conent);
        Init_View();
    }
    private void Init_View(){
        Intent intent = getIntent();
        if(intent != null) {
            TextView shares_name = (TextView) findViewById(R.id.shares_content_name);
            Log.e("shares", intent.getStringExtra("shares_type"));
            shares_name.setText(intent.getStringExtra("shares_name"));
            TextView shares_number = (TextView) findViewById(R.id.shares_content_number);
            shares_number.setText(intent.getStringExtra("shares_number"));
            TextView shares_low = (TextView) findViewById(R.id.shares_content_low);
            shares_low.setText(intent.getStringExtra("shares_low"));
            TextView shares_high = (TextView) findViewById(R.id.shares_content_high);
            shares_high.setText(intent.getStringExtra("shares_high"));
            TextView shares_money = (TextView)findViewById(R.id.shares_content_money);
            shares_money.setText(intent.getStringExtra("shares_money"));
            switch (intent.getStringExtra("shares_type")){
                case "0":typecontent = "股票";break;
                case "1":typecontent = "基金";break;
                case "2":typecontent = "其他";break;
            }
            TextView textView = (TextView)findViewById(R.id.shares_content_type);
            textView.setText(typecontent+"详情");
        }
        ImageView imageButton = (ImageView)findViewById(R.id.shares_content_back);
        imageButton.setOnClickListener(this);
        findViewById(R.id.front_button).setOnClickListener(this);
        findViewById(R.id.friends_button).setOnClickListener(this);
        //viewpager
        Shares_Content_ViewPager = (ViewPager)findViewById(R.id.shares_content_viewpager);
        Indicator indicator = (Indicator)findViewById(R.id.shares_content_indicator);
        Shares_Content_ViewPager.setOffscreenPageLimit(2);
        indicatorViewPager = new IndicatorViewPager(indicator, Shares_Content_ViewPager);
        inflate = LayoutInflater.from(getApplicationContext());
        indicatorViewPager.setAdapter(new SharesContentAdapter(getSupportFragmentManager()));
        Shares_Content_ViewPager.setCanScroll(false);
        Shares_Content_ViewPager.setOffscreenPageLimit(2);
        Shares_Content_ViewPager.setPrepareNumber(0);
        //listview
        ListView ParterListView = (ListView)findViewById(R.id.shares_content_listview);
        ArrayList<FriendsInfo> arrayList = new ArrayList<>();
        arrayList.add(new FriendsInfo(R.drawable.face1,"江竹西","信用值：360"));
        arrayList.add(new FriendsInfo(R.drawable.face2,"常凯申","信用值：360"));
        arrayList.add(new FriendsInfo(R.drawable.face3,"Mr.董","信用值：360"));
        FriendsAdapter friendsAdapter = new FriendsAdapter(this,arrayList);
        ParterListView.setAdapter(friendsAdapter);
    }

    private class SharesContentAdapter extends IndicatorViewPager.IndicatorFragmentPagerAdapter {
        private String[] tabName = {"净值走势", "实时估值"};

        public SharesContentAdapter(FragmentManager fragmentManager) {
            super(fragmentManager);
        }

        @Override
        public int getCount() {
            return tabName.length;
        }
        @Override
        public View getViewForTab(int position, View convertView, ViewGroup container) {
            if (convertView == null) {
                convertView = inflate.inflate(R.layout.tab_top, container, false);
            }
            TextView textView = (TextView) convertView;
            textView.setText(tabName[position]);
            return convertView;
        }

        @Override
        public Fragment getFragmentForPage(int position) {
            Fragment fragment = null;
            switch (position) {
                case 0:
                    fragment = FundFragment.newInstance(0);
                    break;
                case 1:
                    fragment = FundFragment.newInstance(1);
                    break;
            }
            return fragment;
        }
    }
    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.shares_content_back:
                SharesConentActivity.this.finish();
                Log.e("close","it");
                break;
            case R.id.front_button:
                Intent front_intent = new Intent(SharesConentActivity.this, SharesContentFront.class);
                startActivity(front_intent);
                break;
            case R.id.friends_button:
                Intent friends_intent = new Intent(SharesConentActivity.this,ParterActivity.class);
                startActivity(friends_intent);
                break;
        }
    }
}
