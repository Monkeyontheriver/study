package com.oureda.conquer.Info;

/**
 * Created by 刘丰恺 on 2015/8/10.
 */
public class ComLinfo {
    private int Com_Img;
    private String Com_Id;
    private String Com_Project;
    private String Com_DoWhat;
    private String Com_Time;
    private String Com_First;
    private String Com_First_Type;
    private String Com_Second;
    private String Com_Secone_Type;
    private String Com_Third;
    private String Com_Third_Type;

    public ComLinfo(int img, String id, String project, String dowhat, String time, String first,
                    String ftype, String second, String stype, String third, String thtype){
        this.Com_Img = img;
        this.Com_Id = id;
        this.Com_Project = project;
        this.Com_DoWhat = dowhat;
        this.Com_Time = time;
        this.Com_First = first;
        this.Com_First_Type = ftype;
        this.Com_Second = second;
        this.Com_Secone_Type = stype;
        this.Com_Third = third;
        this.Com_Third_Type = thtype;
    }

    public int getCom_Img() {
        return Com_Img;
    }

    public String getCom_Id() {
        return Com_Id;
    }

    public String getCom_Project() {
        return Com_Project;
    }

    public String getCom_DoWhat() {
        return Com_DoWhat;
    }

    public String getCom_Time() {
        return Com_Time;
    }

    public String getCom_First() {
        return Com_First;
    }

    public String getCom_First_Type() {
        return Com_First_Type;
    }

    public String getCom_Second() {
        return Com_Second;
    }

    public String getCom_Secone_Type() {
        return Com_Secone_Type;
    }

    public String getCom_Third() {
        return Com_Third;
    }

    public String getCom_Third_Type() {
        return Com_Third_Type;
    }
}
