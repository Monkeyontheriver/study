package com.oureda.conquer.Activities.Mine;

import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.oureda.conquer.MainFragment.MoneyFragments.OthersFragment;
import com.oureda.conquer.R;
import com.shizhefei.view.indicator.Indicator;
import com.shizhefei.view.indicator.IndicatorViewPager;
import com.shizhefei.view.indicator.slidebar.LayoutBar;
import com.shizhefei.view.indicator.slidebar.ScrollBar;
import com.shizhefei.view.indicator.transition.OnTransitionTextListener;

//我的财富
public class MyWealthActivity extends FragmentActivity implements View.OnClickListener{
    private LayoutInflater inflate;
    private LayoutInflater inflate_2;
    private ViewPager MyWealthViewPager;
    private ViewPager MyWealthViewPager_2;
    private IndicatorViewPager indicatorViewPager;
    private IndicatorViewPager indicatorViewPager_2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_wealth);
        Init_View();
        findViewById(R.id.my_wealth_back).setOnClickListener(this);
        findViewById(R.id.my_wealth_ok).setOnClickListener(this);
    }
    private void Init_View(){
        MyWealthViewPager = (ViewPager)findViewById(R.id.my_wealth_viewpager);
        Indicator indicator = (Indicator) findViewById(R.id.my_wealth_indicator);
        indicator.setScrollBar(new LayoutBar(getApplicationContext(), R.layout.layout_slidebar, ScrollBar.Gravity.CENTENT_BACKGROUND));
        Resources res = getResources();
        float unSelectSize = 16;
        float selectSize = unSelectSize * 1.0f;
        int selectColor = res.getColor(R.color.tab_top_text_2);
        int unSelectColor = res.getColor(R.color.tab_top_text_1);
        indicator.setOnTransitionListener(new OnTransitionTextListener().setColor(selectColor, unSelectColor).setSize(selectSize, unSelectSize));
        MyWealthViewPager.setOffscreenPageLimit(5);
        indicatorViewPager = new IndicatorViewPager(indicator, MyWealthViewPager);
        inflate = LayoutInflater.from(getApplicationContext());
        indicatorViewPager.setAdapter(new EduAdapter(getSupportFragmentManager(),inflate));

        MyWealthViewPager_2 = (ViewPager)findViewById(R.id.my_wealth_viewpager2);
        Indicator indicator_2 = (Indicator) findViewById(R.id.my_wealth_indicator2);
        indicator_2.setScrollBar(new LayoutBar(getApplicationContext(), R.layout.layout_slidebar, ScrollBar.Gravity.CENTENT_BACKGROUND));

        indicator_2.setOnTransitionListener(new OnTransitionTextListener().setColor(selectColor, unSelectColor).setSize(selectSize, unSelectSize));
        MyWealthViewPager_2.setOffscreenPageLimit(5);
        inflate_2 = LayoutInflater.from(getApplicationContext());
        indicatorViewPager_2 = new IndicatorViewPager(indicator_2, MyWealthViewPager_2);
        indicatorViewPager_2.setAdapter(new EduAdapter(getSupportFragmentManager(),inflate_2));
    }

    @Override
    public void onClick(View view) {
        switch(view.getId()){
            case R.id.my_wealth_back:
                finish();
                break;
            case R.id.my_wealth_ok:
                finish();
                break;
        }
    }

    private class EduAdapter extends IndicatorViewPager.IndicatorFragmentPagerAdapter {
        private String[] tabName = {"每星期","每月","每两个月","每季度","每学期"};
        private LayoutInflater inflater;
        public EduAdapter(FragmentManager fragmentManager,LayoutInflater inflater) {
            super(fragmentManager);
            this.inflater = inflater;
        }

        @Override
        public int getCount() {
            return tabName.length;
        }

        @Override
        public View getViewForTab(int position, View convertView, ViewGroup container) {
            if (convertView == null) {
                convertView = inflater.inflate(R.layout.top_padding, container, false);
            }
            TextView textView = (TextView) convertView;
            textView.setText(tabName[position]);
            return textView;
        }

        @Override
        public Fragment getFragmentForPage(int position) {
            Fragment fragment = null;
            fragment = OthersFragment.newInstance();
            return fragment;
        }
    }
}
