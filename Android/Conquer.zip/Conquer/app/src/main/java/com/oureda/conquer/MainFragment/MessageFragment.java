package com.oureda.conquer.MainFragment;

import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.oureda.conquer.MainFragment.MessageFragments.ComFragment;
import com.oureda.conquer.MainFragment.MessageFragments.LatestFragment;
import com.oureda.conquer.MainFragment.MessageFragments.SaleFragment;
import com.oureda.conquer.R;
import com.shizhefei.view.indicator.Indicator;
import com.shizhefei.view.indicator.IndicatorViewPager;
import com.shizhefei.view.indicator.slidebar.ColorBar;
import com.shizhefei.view.indicator.transition.OnTransitionTextListener;

public class MessageFragment extends android.support.v4.app.Fragment {
    private View wrapper;
    private ViewPager Message_ViewPager;
    private LayoutInflater inflate;
    private IndicatorViewPager indicatorViewPager;
    public static MessageFragment newInstance() {
       return new MessageFragment();
    }
    public MessageFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        this.wrapper = inflater.inflate(R.layout.fragment_message, container, false);
        Message_ViewPager = (ViewPager)wrapper.findViewById(R.id.message_viewpager);
        Indicator indicator = (Indicator) wrapper.findViewById(R.id.message_indicator);
        indicator.setScrollBar(new ColorBar(getActivity().getApplicationContext(), Color.rgb(254, 80, 79), 5));
        float unSelectSize = 14;
        float selectSize = unSelectSize * 1.0f;
        Resources res = getResources();
        int selectColor = res.getColor(R.color.tab_top_text_2);
        int unSelectColor = res.getColor(R.color.tab_top_text_1);
        indicator.setOnTransitionListener(new OnTransitionTextListener().setColor(selectColor, unSelectColor).setSize(selectSize, unSelectSize));
        Message_ViewPager.setOffscreenPageLimit(3);
        indicatorViewPager = new IndicatorViewPager(indicator, Message_ViewPager);
        inflate = LayoutInflater.from(getActivity().getApplicationContext());
        // 注意这里的FragmentManager 是 getChildFragmentManager(); 因为是在Fragment里面
        // 而在activity里面用FragmentManager 是 getSupportFragmentManager()
        indicatorViewPager.setAdapter(new MessageAdapter(getChildFragmentManager()));
        return wrapper;
    }
    private class MessageAdapter extends IndicatorViewPager.IndicatorFragmentPagerAdapter {
        private String[] tabName = {"消息广场","最新动态","交流社区"};
        public MessageAdapter(FragmentManager fragmentManager) {
            super(fragmentManager);
        }

        @Override
        public int getCount() {
            return tabName.length;
        }

        @Override
        public View getViewForTab(int position, View convertView, ViewGroup container) {
            if (convertView == null) {
                convertView = inflate.inflate(R.layout.tab_top, container, false);
            }
            TextView textView = (TextView) convertView;
            textView.setText(tabName[position]);
            return convertView;
        }

        @Override
        public Fragment getFragmentForPage(int position) {
            Fragment fragment = null;
            switch (position){
                case 0:
                    fragment = SaleFragment.newInstance();
                    break;
                case 1:
                    fragment = ComFragment.newInstance();
                    break;
                case 2:
                    fragment = LatestFragment.newInstance();
                    break;
            }
            return fragment;
        }
    }
}
