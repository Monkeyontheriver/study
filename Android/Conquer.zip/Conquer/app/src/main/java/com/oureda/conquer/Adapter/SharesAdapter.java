package com.oureda.conquer.Adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.oureda.conquer.Info.SharesInfo;
import com.oureda.conquer.R;

import java.util.ArrayList;

/**
 * Created by 刘丰恺 on 2015/8/8.
 */
public class SharesAdapter extends BaseAdapter {
    private ArrayList<SharesInfo> userList;
    private LayoutInflater layoutInflater;
    private Context context;

    private class SharesListItems{
        private TextView Shares_Name;
        private TextView Shares_Number;
        private TextView Shares_Money;
        private TextView Shares_high;
        private TextView Shares_low;
        private TextView Shares_Friends;
    }


    public SharesAdapter(Context context,ArrayList<SharesInfo> arrayList){
        this.context = context;
        this.layoutInflater = LayoutInflater.from(context);
        this.userList = arrayList;
    }
    public int getCount() {
        return userList.size();
    }

    @Override
    public Object getItem(int position) {
        return userList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        SharesListItems listItem = null;
        if(convertView == null){
            listItem = new SharesListItems();
            convertView = layoutInflater.inflate(R.layout.shares_list_item,null);
            listItem.Shares_Name = (TextView)convertView.findViewById(R.id.shares_name);
            listItem.Shares_Number  = (TextView)convertView.findViewById(R.id.shares_number);
            listItem.Shares_Money = (TextView)convertView.findViewById(R.id.shares_money);
            listItem.Shares_high = (TextView)convertView.findViewById(R.id.shares_high);
            listItem.Shares_low = (TextView)convertView.findViewById(R.id.shares_low);
            listItem.Shares_Friends = (TextView)convertView.findViewById(R.id.your_friends);
            convertView.setTag(listItem);
        }else{
            listItem = (SharesListItems)convertView.getTag();
        }
        SharesInfo sharesinfo = userList.get(position);
        listItem.Shares_Name.setText(sharesinfo.getShares_Name());
        listItem.Shares_Number.setText(sharesinfo.getShares_Number());
        listItem.Shares_Money.setText(sharesinfo.getShares_Money());
        listItem.Shares_high.setText(sharesinfo.getShares_high());
        listItem.Shares_low.setText(sharesinfo.getShares_low());
        listItem.Shares_Friends.setText("您的朋友："+sharesinfo.getFriends()+"也购买了");
        if(sharesinfo.isRecent_high()){
            listItem.Shares_high.setTextColor(Color.rgb(254,80,79));
        }else
            listItem.Shares_high.setTextColor(Color.rgb(132, 254, 106));
        if (sharesinfo.isYear_high()){
            listItem.Shares_low.setTextColor(Color.rgb(103,191,78));
        }else
            listItem.Shares_low.setTextColor(Color.rgb(103,191,78));
        return convertView;
    }
}
