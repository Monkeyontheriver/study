package com.oureda.conquer.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.oureda.conquer.Info.LatestInfo;
import com.oureda.conquer.Activities.Message.LatestContentActivity;
import com.oureda.conquer.R;

import java.util.ArrayList;

/**
 * Created by 刘丰恺 on 2015/8/10.
 */
public class LatestAdapter extends BaseAdapter {
    private Context context;
    private LayoutInflater layoutInflater;
    private ArrayList<LatestInfo> userList;

    private class LatestListView{
        private ImageView Latest_Img;
        private TextView Latest_Id;
        private TextView Latest_TalkLog;
        private TextView Latest_CreditLine;
        private TextView Latest_TalkIt;
        private TextView Latest_LikeIt;
        private TextView Latest_HaveWatched;
        private TextView Latest_Time;
        private ImageButton Latest_LikeIt_Button;
        private ImageButton Latest_TalkIt_Button;
    }

    public LatestAdapter(Context context,ArrayList<LatestInfo> arrayList) {
        this.context = context;
        this.layoutInflater = LayoutInflater.from(context);
        this.userList = arrayList;
    }
    @Override
    public int getCount() {
        return userList.size();
    }

    @Override
    public Object getItem(int i) {
        return userList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LatestListView latestListView = null;
        if (view == null) {
            latestListView = new LatestListView();
            view = layoutInflater.inflate(R.layout.latest_list_item, null);
            latestListView.Latest_Img = (ImageView) view.findViewById(R.id.latest_img);
            latestListView.Latest_Id = (TextView) view.findViewById(R.id.latest_id);
            latestListView.Latest_TalkLog = (TextView) view.findViewById(R.id.latest_talklog);
            latestListView.Latest_CreditLine = (TextView) view.findViewById(R.id.latest_cl);
            latestListView.Latest_LikeIt = (TextView) view.findViewById(R.id.latest_likeit);
            latestListView.Latest_TalkIt = (TextView) view.findViewById(R.id.latest_talkit);
            latestListView.Latest_HaveWatched = (TextView) view.findViewById(R.id.latest_havewatched);
            latestListView.Latest_LikeIt_Button = (ImageButton) view.findViewById(R.id.latest_likeit_button);
            latestListView.Latest_TalkIt_Button = (ImageButton) view.findViewById(R.id.latest_talkit_button);
            latestListView.Latest_Time = (TextView) view.findViewById(R.id.latest_time);
            view.setTag(latestListView);
        } else {
            latestListView = (LatestListView) view.getTag();
        }
        LatestInfo latestInfo = userList.get(i);
        latestListView.Latest_Img.setImageResource(latestInfo.getLatest_Img());
        latestListView.Latest_Id.setText(latestInfo.getLatest_Id());
        latestListView.Latest_TalkLog.setText(latestInfo.getLatest_TalkLog());
        latestListView.Latest_CreditLine.setText(latestInfo.getLatest_CreditLine());
        latestListView.Latest_LikeIt.setText(latestInfo.getLatest_LikeIt());
        latestListView.Latest_TalkIt.setText(latestInfo.getLatest_TalkIt());
        latestListView.Latest_HaveWatched.setText(latestInfo.getLatest_HaveWatched());
        latestListView.Latest_Time.setText(latestInfo.getLatest_Time());
        if (latestInfo.isLatest_IfTouched()) {
            latestListView.Latest_LikeIt_Button.performClick();
            latestListView.Latest_LikeIt_Button.setImageResource(R.drawable.icon_dianzanshixin_pressed);
        }
        boolean old_condition = latestInfo.isLatest_IfTouched();
        OnClickLinstener onClickLinstener = new OnClickLinstener(latestListView,old_condition);
        latestListView.Latest_LikeIt_Button.setOnClickListener(onClickLinstener);
        TextOnClickLinstener textOnClickLinstener = new TextOnClickLinstener(latestInfo);
        latestListView.Latest_TalkLog.setOnClickListener(textOnClickLinstener);
        return view;
    }
    private class OnClickLinstener implements View.OnClickListener{
        private LatestListView latestListView;
        private boolean condition;
        public OnClickLinstener(LatestListView llv,boolean con){
            this.latestListView = llv;
            this.condition = con;
        }
        @Override
        public void onClick(View view) {
            if(condition){
                latestListView.Latest_LikeIt.setText(String.valueOf(Integer.parseInt(latestListView.Latest_LikeIt.getText().toString()) - 1));
                condition = !condition;
                latestListView.Latest_LikeIt_Button.setImageResource(R.drawable.icon_dianzan_unpressed);
            }else {
                latestListView.Latest_LikeIt.setText(String.valueOf(Integer.parseInt(latestListView.Latest_LikeIt.getText().toString()) + 1));
                condition = !condition;
                latestListView.Latest_LikeIt_Button.setImageResource(R.drawable.icon_dianzanshixin_pressed);
            }
        }
    }
    private class TextOnClickLinstener implements View.OnClickListener {
        private LatestInfo latestInfo;
        public TextOnClickLinstener(LatestInfo latestInfo){
            this.latestInfo = latestInfo;
        }
        @Override
        public void onClick(View view) {
            Intent intent = new Intent(context, LatestContentActivity.class);
            intent.putExtra("latest_img",String.valueOf(latestInfo.getLatest_Img()));
            intent.putExtra("latest_id",latestInfo.getLatest_Id());
            intent.putExtra("latest_time",latestInfo.getLatest_Time());
            intent.putExtra("latest_text",latestInfo.getLatest_TalkLog());
            context.startActivity(intent);
        }
    }
}
