package com.oureda.conquer.Info;

/**
 * Created by 刘丰恺 on 2015/8/13.
 */
public class IncomeInfo {
    private int Income_Progress;
    private String Income_Id;
    private String Income_pre;
    private String Income_First_Item;
    private String Income_Second_Item;
    private String Income_Third_Item;

    public IncomeInfo(int pro,String id,String pre,String fi,String si,String thi){
        this.Income_Progress = pro;
        this.Income_Id = id;
        this.Income_pre = pre;
        this.Income_First_Item = fi;
        this.Income_Second_Item = si;
        this.Income_Third_Item = thi;
    }
    public int getIncome_Progress() {
        return Income_Progress;
    }

    public String getIncome_Id() {
        return Income_Id;
    }

    public String getIncome_pre() {
        return Income_pre;
    }

    public String getIncome_First_Item() {
        return Income_First_Item;
    }

    public String getIncome_Second_Item() {
        return Income_Second_Item;
    }

    public String getIncome_Third_Item() {
        return Income_Third_Item;
    }
}
