package com.oureda.conquer.Activities.Mine;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;

import com.oureda.conquer.R;
import com.oureda.conquer.UI.DialPlateView;

import java.util.Timer;
import java.util.TimerTask;

//我的信用
public class MyCreditActivity extends Activity implements View.OnClickListener{
    private DialPlateView dialplate;
    private int index = 0;
    private Timer timer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_credit);
        findViewById(R.id.my_credit_back).setOnClickListener(this);
        dialplate = (DialPlateView) findViewById(R.id.dialplate);
        dialplate.setMin(0);
        dialplate.setMax(700);
        dialplate.setProgressColorStatus(true);
        dialplate.setBackgroundColor(Color.WHITE);
        dialplate.setTextJudge("投资信用");
        dialplate.setTextJudgeTime("评估时间：2015.7.22");
        dialplate.setJudgeTimeColor(Color.parseColor("#acacac"));
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        index += 1;
                        dialplate.setProgress(index);
                    }
                });
            }
        }, 1000, 16);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.my_credit_back:
                finish();
                break;

        }
    }
}
