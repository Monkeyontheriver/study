package com.oureda.conquer.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.oureda.conquer.Info.WelInfo;
import com.oureda.conquer.R;

import java.util.ArrayList;

/**
 * Created by 刘丰恺 on 2015/8/10.
 */
public class WelAdapt extends BaseAdapter {
    private LayoutInflater layoutInflater;
    private Context context;
    private ArrayList<WelInfo> userList;


    private class  WelListView{
        private TextView Wel_Type;
        private TextView Wel_Title;
        private TextView Wel_Text;
    }
    public WelAdapt(Context context,ArrayList<WelInfo> arrayList){
        this.context = context;
        this.layoutInflater = LayoutInflater.from(context);
        this.userList = arrayList;
    }
    @Override
    public int getCount() {
        return userList.size();
    }

    @Override
    public Object getItem(int i) {
        return userList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        WelListView welListView = null;
        if(view == null){
            welListView = new WelListView();
            view = layoutInflater.inflate(R.layout.wealthedu_list_item,null);
            welListView.Wel_Type = (TextView)view.findViewById(R.id.wel_type);
            welListView.Wel_Title = (TextView)view.findViewById(R.id.wel_title);
            welListView.Wel_Text = (TextView)view.findViewById(R.id.wel_text);
            view.setTag(welListView);
        }else {
            welListView = (WelListView)view.getTag();
        }
        WelInfo welInfo = userList.get(i);
        welListView.Wel_Type.setText(welInfo.getWel_Type());
        welListView.Wel_Title.setText(welInfo.getWel_Title());
        welListView.Wel_Text.setText(welInfo.getWel_Text());
        return view;
    }
}
