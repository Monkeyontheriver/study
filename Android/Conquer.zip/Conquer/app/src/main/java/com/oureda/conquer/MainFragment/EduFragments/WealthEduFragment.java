package com.oureda.conquer.MainFragment.EduFragments;


import android.content.Intent;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.oureda.conquer.Adapter.WelAdapt;
import com.oureda.conquer.Info.WelInfo;
import com.oureda.conquer.R;
import com.oureda.conquer.Activities.Education.WelContentActivity;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class WealthEduFragment extends android.support.v4.app.Fragment {
    private View wrapper;
    private String string = "许多管理者都很忙天天发展业务，处理员工问题，但是忙碌之中，却忘了注意一些公司的长远大问题，所以，到底这个问题已经追悔莫及才足以很恶心严重。 \n" +
            "\n" +
            "理财专家麦劳查韦斯（爱德华Mendlowitz）建议，其实，只要习惯经理定期注意一些简单的财务报表，就能够掌握公司的发展趋势。一旦出现警示灯，它可以处理一次。 \n" +
            "\n" +
            "产品的销售。如果你看看每日收入报告，其中可能隐藏着许多陷阱之中。例如，虽然有公司的营业额和利润不断上升，但销售实际上下降的市场份额正在萎缩。之所以收入增长是由于产品价格调整之间的关系。因此，经理人必须定期追踪销售量，以清除公司的经营状况的把握。 \n" +
            "\n" +
            "盈亏平衡点。在许多情况下，你必须要等一个月了财务报表后，该公司近期的表现不知道怎么办。但是这一次，这个差距很可能会影响你的决策速度。如果你能请提供公司的财务盈亏平衡分析，也就是说，你想卖多少产品，一个月来平衡，记住这个数字在任何时候，你可以立即确定这是否有钱时，还是亏钱。 \n" +
            "\n" +
            "外购原料比例。你的公司有多大比例用于纸张，塑料等原材料的钱？总成交数字使用和比较。通常情况下，这个比例应该很稳定，没有一两个月的波动关系，但如果有不断增加或减少的趋势，我们应该引起重视。也许你太多的库存，成本没有控制好，或者库存太少，碰到突然增加的订单，你可能消化不了。 \n" +
            "\n" +
            "银行对账单。银行会送你月结单，不要以为会计人员会去检查。其实，每个人每天忙着做很多事情，没有人注意这个重要的工作。你知道，这很可能是你的公司有好几年了，没有人检查了该公司的账户。 积压。有些订单进来了，但它并没有被处理，从而导致延迟交货。只要你看看订单的需求积压，就可以知道公司是否有问题，该怎么严重的问题。每件订单积压，说生气的顾客，愤怒的顾客看到你的公司有多少是累积性的。一个公司发现，客户往往反应延迟交付，经过深入审查，才发现，其实这个问题始终是开始处理堆栈运输部门从上面的命令。因此，每一个最后收到的订单，但最早完成后，按以下顺序，从未被推迟了几天。知道有多少订单，你的公司积压，这里的问题是很容易解决这个问题。 \n" +
            "\n" +
            "返回记录。如果增加收益的数量，这意味着内部质量控制问题。因此，掌握退货数量，是解决问题的重要关键不失控，当它解决。 \n" +
            "\n" +
            "员工。员工计算有多少人每个月。随着业务量的增加，员工人数由公司聘用的，可能在不知不觉中成长，甚至当业务没有成长，增加员工数量保持沉默。例如，如果你的公司有25人，另外的五个月，的确什么不是。问他的下属给你的每月统计数字，员工人数，让你掌握生长曲线。你看，公司没有雇用过大。 \n" +
            "忙碌的工作中，抓住这些基本而重要的数字，让您迅速掌握公司的经营状况。它可以说是另一种一分钟管理。";

    private String s2 = "关于股票购买流程的那些事\n" +
            "炒股需要先开户，开户的话可以找证券公司的营业部柜台办理，柜台营业员会帮助办理相关事宜；现在一些开通银证通的银行柜台也可以代理开户。\n" +
            "具体流程可参考下面步骤：\n" +
            "（一）办理深圳、上海证券账户卡\n";

    private String s3 = "深圳证券账户卡\n" +
            "投资者：可以通过所在地的证券营业部或证券登记机构办理，需提供本人有效身份证件及复印件，委托他人代办的，还需提供代办人身份证及复印件。\n" +
            "法人：持营业执照（及复印件）、法人委托书、法人代表证明书和经办人身份证办理。\n" +
            "证券投资基金、保险公司：开设账户卡则需到深圳证券交易所直接办理。\n" +
            "开户费用：个人50元/每个账户；机构500元/每个账户。\n";

    private String s4 = "上海证券账户卡\n" +
            "投资者：可以到上海证券中央登记结算公司在各地的开户代理机构处，办理有关申请开立证券账户手续，带齐有效省份证件和复印件。";
    public static WealthEduFragment newInstance(){
        return new WealthEduFragment();
    }

    public WealthEduFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(final LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment[行业资讯]炒股必备入门常识
        this.wrapper = inflater.inflate(R.layout.fragment_wealth_edu, container, false);
        ListView Wel_ListView = (ListView)wrapper.findViewById(R.id.wel_listview);
        ArrayList<WelInfo> arrayList = new ArrayList<>();
        arrayList.add(new WelInfo("[基础常识]","你会看财务报表么？","\u3000\u3000"+string));
        arrayList.add(new WelInfo("[行业资讯]","炒股必备入门常识？","\u3000\u3000"+s2));
        arrayList.add(new WelInfo("[基础常识]","关于股票购买流程的那些事","\u3000\u3000"+s3));
        arrayList.add(new WelInfo("[行业资讯]","浅谈k线图？","\u3000\u3000"+s4));
        arrayList.add(new WelInfo("[基础常识]","基本分析与技术分析","\u3000\u3000"+string));
        arrayList.add(new WelInfo("[基础常识]", "你会看财务报表么？", "\u3000\u3000" + string));
        arrayList.add(new WelInfo("[基础常识]", "你会看财务报表么？", "\u3000\u3000" + string));
        WelAdapt welAdapt = new WelAdapt(getActivity(),arrayList);
        Wel_ListView.setAdapter(welAdapt);
        Wel_ListView.setVerticalScrollBarEnabled(true);
        Wel_ListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(getActivity(), WelContentActivity.class);
                intent.putExtra("wel_title",((TextView)view.findViewById(R.id.wel_title)).getText().toString());
                intent.putExtra("wel_text",((TextView)view.findViewById(R.id.wel_text)).getText().toString());
                getActivity().startActivity(intent);
            }
        });
        return wrapper;
    }


}
