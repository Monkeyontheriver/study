package com.oureda.conquer.MainFragment;


import android.app.Fragment;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.oureda.conquer.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class ChartsFragment extends android.support.v4.app.Fragment {



    public static ChartsFragment newInstance(int number){
        Log.e("chartsnumber",""+number);
        return new ChartsFragment();
    }

    public ChartsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_charts, container, false);

    }


}
