package com.oureda.conquer.Info;

/**
 * Created by 刘丰恺 on 2015/8/10.
 */
public class SaleInfo  {
    private int Sale_Img;
    private String Sale_Name;
    private String Sale_Number;
    private String Sale_Low_Number;
    private String Sale_Type;

    public int getSale_Img() {
        return Sale_Img;
    }

    private String Sale_Condition;

    public SaleInfo(int sale_Img,String name,String number,String low_number,String type,String condition){
        this.Sale_Img = sale_Img;
        this.Sale_Name = name;
        this.Sale_Low_Number = low_number;
        this.Sale_Number = number;
        this.Sale_Type = type;
        this.Sale_Condition = condition;
    }

    public String getSale_Name() {
        return Sale_Name;
    }

    public String getSale_Number() {
        return Sale_Number;
    }

    public String getSale_Low_Number() {
        return Sale_Low_Number;
    }

    public String getSale_Type() {
        return Sale_Type;
    }

    public String getSale_Condition() {
        return Sale_Condition;
    }
}
