package com.oureda.conquer;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;


public class RegistActivity extends Activity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_regist);
        findViewById(R.id.regist_back).setOnClickListener(this);
        findViewById(R.id.next_second_button).setOnClickListener(this);

    }


    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.next_second_button:
                Intent next_to_login_intent = new Intent(RegistActivity.this,LoginActivity.class);
                startActivity(next_to_login_intent);
                break;
            case R.id.regist_back:
                finish();
                break;
        }
    }
}
