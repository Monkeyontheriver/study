package com.oureda.conquer;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

//登录
public class LoginActivity extends Activity implements View.OnClickListener {
    private EditText username;
    private EditText password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Init_View();
    }
    private void Init_View(){
        username = (EditText)findViewById(R.id.username);
        password = (EditText)findViewById(R.id.password);
        findViewById(R.id.login_button).setOnClickListener(this);
        findViewById(R.id.close_button).setOnClickListener(this);
        findViewById(R.id.newuser).setOnClickListener(this);
        findViewById(R.id.forgetpassword).setOnClickListener(this);
    }
    private void Login(String username,String password){

    }
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.login_button:
                //添加登录
                Log.e("login", "");
                Intent login_intent = new Intent(LoginActivity.this,MainActivity.class);
                startActivity(login_intent);
                break;
            case R.id.forgetpassword:
                //跳转忘记密码
                Intent forget_intent = new Intent(LoginActivity.this,FirstRegistActivity.class);
                forget_intent.setData(Uri.parse("forget"));
                startActivity(forget_intent);
                break;
            case R.id.newuser:
                //跳转注册
                Intent regist_intent = new Intent(LoginActivity.this,FirstRegistActivity.class);
                startActivity(regist_intent);
                break;
            case R.id .close_button:
                moveTaskToBack(true);//关闭移入后台
                break;
        }
    }
}
