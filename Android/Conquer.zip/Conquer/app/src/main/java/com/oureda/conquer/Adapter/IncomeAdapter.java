package com.oureda.conquer.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.oureda.conquer.Info.IncomeInfo;
import com.oureda.conquer.R;
import com.oureda.conquer.UI.RoundProgressBar;

import java.util.ArrayList;

/**
 * Created by 刘丰恺 on 2015/8/13.
 */
public class IncomeAdapter extends BaseAdapter {
    private LayoutInflater layoutInflater;
    private Context context;
    private ArrayList<IncomeInfo> userlist;
    public IncomeAdapter(Context context, ArrayList<IncomeInfo> userlist) {
        this.layoutInflater = LayoutInflater.from(context);
        this.context = context;
        this.userlist = userlist;
    }

    private class IncomeListView{
        private RoundProgressBar Income_Progress;
        private TextView Income_Id;
        private TextView Income_pre;
        private TextView Income_First_Item;
        private TextView Income_Second_Item;
        private TextView Income_Third_Item;
    }

    @Override
    public int getCount() {
        return userlist.size();
    }

    @Override
    public Object getItem(int i) {
        return userlist.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        IncomeListView incomeListView = null;
        if(view == null){
            int times = 0;
            incomeListView = new IncomeListView();
            view = layoutInflater.inflate(R.layout.my_income_list_item,null);
            incomeListView.Income_Progress = (RoundProgressBar)view.findViewById(R.id.roundProgressBar);
            incomeListView.Income_Id = (TextView)view.findViewById(R.id.my_income_list_item_id);
            incomeListView.Income_pre = (TextView)view.findViewById(R.id.my_income_list_item_pre);
            incomeListView.Income_First_Item = (TextView)view.findViewById(R.id.my_income_list_item_first);
            incomeListView.Income_Second_Item = (TextView)view.findViewById(R.id.my_income_list_item_second);
            incomeListView.Income_Third_Item = (TextView)view.findViewById(R.id.my_income_list_item_third);
            view.setTag(incomeListView);
            incomeListView = Init_View(userlist.get(i),incomeListView,times);
        }else {
            incomeListView = (IncomeListView)view.getTag();
            int times = 1;
            incomeListView = Init_View(userlist.get(i),incomeListView,times);
        }
        return view;
    }

    private IncomeListView Init_View(final IncomeInfo incomeInfo,IncomeListView incomeListView,int times){
        incomeListView.Income_Id.setText(incomeInfo.getIncome_Id());
        incomeListView.Income_pre.setText(incomeInfo.getIncome_pre());
        incomeListView.Income_First_Item.setText(incomeInfo.getIncome_First_Item());
        incomeListView.Income_Second_Item.setText(incomeInfo.getIncome_Second_Item());
        incomeListView.Income_Third_Item.setText(incomeInfo.getIncome_Third_Item());
        if(times == 0){
            final IncomeListView finalIncomeListView = incomeListView;
            new Thread(new Runnable() {
                @Override
                public void run() {
                    int progress = 0;
                    while(progress <= incomeInfo.getIncome_Progress()){
                        progress += 3;
                        System.out.println(progress);
                        finalIncomeListView.Income_Progress.setProgress(progress);
                        try {
                            Thread.sleep(100);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }).start();
        }
        return incomeListView;
    }
}
