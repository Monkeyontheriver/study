package com.oureda.conquer.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.oureda.conquer.Info.FriendsInfo;
import com.oureda.conquer.R;

import java.util.ArrayList;

/**
 * Created by 刘丰恺 on 2015/8/14.
 */
public class FriendsAdapter extends BaseAdapter {
    private Context context;
    private LayoutInflater layoutInflater;
    private ArrayList<FriendsInfo> userlist;

    private class FriendsListView{
        private ImageView Friends_Img;
        private TextView Friends_Name;
        private TextView Friends_Cridet;
    }

    public FriendsAdapter(Context context, ArrayList<FriendsInfo> userlist) {
        this.context = context;
        this.userlist = userlist;
        this.layoutInflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return userlist.size();
    }

    @Override
    public Object getItem(int i) {
        return userlist.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        FriendsListView friendsListView = null;
        if(view == null){
            friendsListView = new FriendsListView();
            view = layoutInflater.inflate(R.layout.friends_list_item,null);
            friendsListView.Friends_Img = (ImageView)view.findViewById(R.id.friends_item_img);
            friendsListView.Friends_Name = (TextView)view.findViewById(R.id.friends_item_name);
            friendsListView.Friends_Cridet = (TextView)view.findViewById(R.id.friends_item_credit);
            view.setTag(friendsListView);
        }else {
            friendsListView = (FriendsListView)view.getTag();
        }
        FriendsInfo friendsInfo = userlist.get(i);
        friendsListView.Friends_Img.setImageResource(friendsInfo.getFriends_Img());
        friendsListView.Friends_Name.setText(friendsInfo.getFriends_Name());
        friendsListView.Friends_Cridet.setText(friendsInfo.getFriends_Cridet());
        return view;
    }
}
