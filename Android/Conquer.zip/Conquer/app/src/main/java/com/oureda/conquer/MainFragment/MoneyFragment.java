package com.oureda.conquer.MainFragment;


import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.Rect;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.oureda.conquer.MainFragment.MoneyFragments.SharesFragment;
import com.oureda.conquer.R;
import com.shizhefei.view.indicator.Indicator;
import com.shizhefei.view.indicator.IndicatorViewPager;
import com.shizhefei.view.indicator.slidebar.ColorBar;
import com.shizhefei.view.indicator.transition.OnTransitionTextListener;


public class MoneyFragment extends Fragment {
    private View wrapper;
    private ViewPager Money_ViewPager;
    private LayoutInflater inflate;
    private IndicatorViewPager indicatorViewPager;
    private PopupWindow popupWindow;
    private static boolean SHOWING = false;

    public MoneyFragment() {
        // Required empty public constructor
    }

    public static MoneyFragment newInstance(){
        return new MoneyFragment();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        this.wrapper = inflater.inflate(R.layout.fragment_money, container, false);
        Money_ViewPager = (ViewPager)wrapper.findViewById(R.id.money_viewpager);
        Indicator indicator = (Indicator) wrapper.findViewById(R.id.money_indicator);
        indicator.setScrollBar(new ColorBar(getActivity().getApplicationContext(), Color.rgb(254,80,79), 5));
        float unSelectSize = 14;
        float selectSize = unSelectSize * 1.0f;
        Resources res = getResources();
        int selectColor = res.getColor(R.color.tab_top_text_2);
        int unSelectColor = res.getColor(R.color.tab_top_text_1);
        indicator.setOnTransitionListener(new OnTransitionTextListener().setColor(selectColor, unSelectColor).setSize(selectSize, unSelectSize));
        Money_ViewPager.setOffscreenPageLimit(3);
        indicatorViewPager = new IndicatorViewPager(indicator, Money_ViewPager);
        inflate = LayoutInflater.from(getActivity().getApplicationContext());
        // 注意这里的FragmentManager 是 getChildFragmentManager(); 因为是在Fragment里面
        // 而在activity里面用FragmentManager 是 getSupportFragmentManager()
        indicatorViewPager.setAdapter(new MoneyAdapter(getChildFragmentManager()));
        wrapper.findViewById(R.id.money_paixu).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SHOWING = !SHOWING;
                if(SHOWING) {
                    View popupWindow_view = getActivity().getLayoutInflater().inflate(R.layout.popupwindow, null, false);
                    // 创建PopupWindow实例,200,LayoutParams.MATCH_PARENT分别是宽度和高度
                    popupWindow = new PopupWindow(popupWindow_view, dip2px(150), LinearLayout.LayoutParams.WRAP_CONTENT, true);
                    // 设置动画效果
                    popupWindow.setAnimationStyle(R.style.AnimationFade);
                    // 这里是位置显示方式,在屏幕的左侧
                    Rect frame = new Rect();
                    int statusBarHeight = frame.top;
                    popupWindow.showAtLocation(wrapper, Gravity.RIGHT|Gravity.TOP , 0, dip2px(64) + statusBarHeight);
                    // 点击其他地方消失
                    popupWindow_view.setOnTouchListener(new View.OnTouchListener() {
                        @Override
                        public boolean onTouch(View v, MotionEvent event) {
                            // TODO Auto-generated method stub
                            if (popupWindow != null && popupWindow.isShowing()) {
                                popupWindow.dismiss();
                                popupWindow = null;
                            }
                            return false;
                        }
                    });
                }
            }
        });
        return wrapper;
    }

    public int dip2px(float dpValue) {
        final float scale = this.getResources().getDisplayMetrics().density;
        return (int) (dpValue * scale + 0.5f);
    }

    private class MoneyAdapter extends IndicatorViewPager.IndicatorFragmentPagerAdapter {
        private String[] tabName = {"股票","基金","其他"};
        public MoneyAdapter(FragmentManager fragmentManager) {
            super(fragmentManager);
        }

        @Override
        public int getCount() {
            return tabName.length;
        }

        @Override
        public View getViewForTab(int position, View convertView, ViewGroup container) {
            if (convertView == null) {
                convertView = inflate.inflate(R.layout.tab_top, container, false);
            }
            TextView textView = (TextView) convertView;
            textView.setText(tabName[position]);
            return convertView;
        }

        @Override
        public Fragment getFragmentForPage(int position) {
            Fragment fragment = null;
            switch (position){
                case 0:
                    fragment = SharesFragment.newInstance(0);
                    break;
                case 1:
                    fragment = SharesFragment.newInstance(1);
                    break;
                case 2:
                    fragment = SharesFragment.newInstance(2);
                    break;
            }
            return fragment;
        }
    }

}

