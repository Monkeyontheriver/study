package com.oureda.conquer.Activities.Mine;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

import com.oureda.conquer.Adapter.FriendsAdapter;
import com.oureda.conquer.Info.FriendsInfo;
import com.oureda.conquer.R;

import java.util.ArrayList;

public class MyFriendsActivity extends Activity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_friends);
        findViewById(R.id.my_friends_back).setOnClickListener(this);
        ListView ParterListView = (ListView)findViewById(R.id.my_friends_listview);
        ArrayList<FriendsInfo> arrayList = new ArrayList<>();
        arrayList.add(new FriendsInfo(R.drawable.face1,"种花少年","信用值：160"));
        arrayList.add(new FriendsInfo(R.drawable.face2,"阿克胡","信用值：3600"));
        arrayList.add(new FriendsInfo(R.drawable.face3,"眼镜侠","信用值：360"));
        arrayList.add(new FriendsInfo(R.drawable.face4,"李文泽","信用值：360"));
        arrayList.add(new FriendsInfo(R.drawable.face5,"赵子杨","信用值：360"));
        arrayList.add(new FriendsInfo(R.drawable.face6,"李选","信用值：360"));
        arrayList.add(new FriendsInfo(R.drawable.face7,"刘文牵","信用值：360"));
        arrayList.add(new FriendsInfo(R.drawable.face8,"刘岳麓","信用值：360"));
        arrayList.add(new FriendsInfo(R.drawable.face9,"文则","信用值：360"));
        FriendsAdapter friendsAdapter = new FriendsAdapter(this,arrayList);
        ParterListView.setAdapter(friendsAdapter);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.my_friends_back:
                finish();
                break;
        }
    }
}
