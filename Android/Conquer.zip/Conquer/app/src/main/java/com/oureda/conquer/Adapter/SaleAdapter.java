package com.oureda.conquer.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.oureda.conquer.Info.SaleInfo;
import com.oureda.conquer.R;

import java.util.ArrayList;

/**
 * Created by 刘丰恺 on 2015/8/10.
 */
public class SaleAdapter extends BaseAdapter {
    private ArrayList<SaleInfo> userList;
    private LayoutInflater layoutInflater;
    private Context context;

    private class SaleListItems{
        private ImageView Sale_Img;
        private TextView Sale_Name;
        private TextView Sale_Number;
        private TextView Sale_Low_Number;
        private TextView Sale_Type;
        private TextView Sale_Condition;
    }
    public SaleAdapter(Context context,ArrayList<SaleInfo> arrayList) {
        this.context = context;
        this.layoutInflater = LayoutInflater.from(context);
        this.userList = arrayList;
    }

    @Override
    public int getCount() {
        return userList.size();
    }

    @Override
    public Object getItem(int i) {
        return userList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        SaleListItems saleListItems = null;
        if(view == null){
            saleListItems = new SaleListItems();
            view = layoutInflater.inflate(R.layout.sale_list_item,null);
            saleListItems.Sale_Img = (ImageView)view.findViewById(R.id.sale_img);
            saleListItems.Sale_Name = (TextView)view.findViewById(R.id.sale_name);
            saleListItems.Sale_Number = (TextView)view.findViewById(R.id.sale_number);
            saleListItems.Sale_Low_Number = (TextView)view.findViewById(R.id.sale_low_number);
            saleListItems.Sale_Condition = (TextView)view.findViewById(R.id.sale_condition);
            saleListItems.Sale_Type = (TextView)view.findViewById(R.id.sale_type);
            view.setTag(saleListItems);
        }else {
            saleListItems = (SaleListItems)view.getTag();
        }
        SaleInfo saleInfo = userList.get(i);
        saleListItems.Sale_Img.setImageResource(saleInfo.getSale_Img());
        saleListItems.Sale_Name.setText(saleInfo.getSale_Name());
        saleListItems.Sale_Number.setText(saleInfo.getSale_Number());
        saleListItems.Sale_Low_Number.setText(saleInfo.getSale_Low_Number());
        saleListItems.Sale_Condition.setText(saleInfo.getSale_Condition());
        saleListItems.Sale_Type.setText(saleInfo.getSale_Type());
        return view;
    }
}
