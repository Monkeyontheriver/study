package com.oureda.conquer.Activities.Mine;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

import com.oureda.conquer.Adapter.MessageAdapter;
import com.oureda.conquer.Info.MessageInfo;
import com.oureda.conquer.R;

import java.util.ArrayList;

public class MyMessageActivity extends Activity implements View.OnClickListener {
    private MessageAdapter messageAdapter;
    private ListView My_Message_ListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_message);
        My_Message_ListView = (ListView)findViewById(R.id.my_message_listview);
        ArrayList<MessageInfo> arrayList = new ArrayList<>();
        arrayList.add(new MessageInfo("您的项目",R.drawable.icon_message_project,"今天22:01","已通过审核","学生贷LV093535", Color.rgb(69,165,223)));
        arrayList.add(new MessageInfo("您的拍卖",R.drawable.icon_message_auction,"今天22:01","以$75拍出","西瓜微透印花短袖", Color.rgb(100,201,178)));
        arrayList.add(new MessageInfo("您的股票",R.drawable.icon_message_shares,"今天22:01","单日涨幅超过3%","中顺集团控股", Color.rgb(247,72,75)));
        arrayList.add(new MessageInfo("您的提问",R.drawable.icon_message_newanswer,"今天22:01","有了新的回答","\"赎金的管理费\"", Color.rgb(173,111,194)));
        arrayList.add(new MessageInfo("您的基金",R.drawable.icon_message_fund,"今天22:01","已完成融资","易方达科技", Color.rgb(242,194,0)));
        arrayList.add(new MessageInfo("您的项目已完成",R.drawable.icon_message_project_completed,"今天22:01","您的项目已完成","购买学生贷LV093535", Color.rgb(232,128,39)));
        arrayList.add(new MessageInfo("已赚到",R.drawable.icon_mine_message_rmb,"今天22:01","已赚到$250","通过学生贷LV093535", Color.rgb(30,189,160)));
        messageAdapter = new MessageAdapter(this,arrayList);
        My_Message_ListView.setAdapter(messageAdapter);
        findViewById(R.id.my_message_back).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.my_message_back:
                finish();
                break;
        }
    }
}
