package com.oureda.conquer.Activities.Message;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.oureda.conquer.R;

//朋友圈的子页面
public class LatestContentActivity extends Activity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_latest_content);
        Intent intent = getIntent();
        if(intent != null){
            TextView Latest_Id = (TextView)findViewById(R.id.latest_content_id);
            Latest_Id.setText(intent.getStringExtra("latest_id"));
            ImageView Latest_Img = (ImageView)findViewById(R.id.latest_content_img);
            Latest_Img.setImageResource(Integer.parseInt(intent.getStringExtra("latest_img")));
            TextView Latest_Time = (TextView)findViewById(R.id.latest_content_time);
            Latest_Time.setText(intent.getStringExtra("latest_time"));
            TextView Latest_Text = (TextView)findViewById(R.id.latest_content_text);
            Latest_Text.setText(intent.getStringExtra("latest_text"));
            findViewById(R.id.latest_content_back).setOnClickListener(this);
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.latest_content_back:
                finish();
                break;
        }
    }
}
