package com.oureda.conquer.Activities.Mine;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

import com.oureda.conquer.Adapter.IncomeAdapter;
import com.oureda.conquer.Info.IncomeInfo;
import com.oureda.conquer.R;

import java.util.ArrayList;

//累计收入
public class IncomeActivity extends Activity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_income);
        findViewById(R.id.income_back).setOnClickListener(this);
        ListView IncomeListView = (ListView)findViewById(R.id.income_listview);
        ArrayList<IncomeInfo> arrayList = new ArrayList<>();
        arrayList.add(new IncomeInfo(49,"上海石化股票","8.50%","37人","31天","2000元"));
        arrayList.add(new IncomeInfo(49,"江南皮革厂","3.50%","81人","31天","1000元"));
        arrayList.add(new IncomeInfo(100,"黄鹤楼","10.50%","37人","31天","1000元"));
        arrayList.add(new IncomeInfo(49,"温州皮革厂","9.50%","37人","31天","4000元"));
        arrayList.add(new IncomeInfo(20,"AIPC实业","8.50%","317人","31天","3000元"));
        arrayList.add(new IncomeInfo(30,"可菲药水厂","8.50%","32人","31天","1000元"));
        arrayList.add(new IncomeInfo(49,"元首药业有限公司","8.50%","37人","31天","10000元"));
        arrayList.add(new IncomeInfo(49,"逸风实业","8.50%","37人","31天","10000元"));
        arrayList.add(new IncomeInfo(100,"上海石化股票","8.50%","37人","31天","1000元"));
        arrayList.add(new IncomeInfo(49,"上海石化股票","8.50%","27人","31天","1000元"));
        arrayList.add(new IncomeInfo(49,"上海石化股票","8.50%","37人","31天","1000元"));
        IncomeAdapter incomeAdapter = new IncomeAdapter(this,arrayList);
        IncomeListView.setAdapter(incomeAdapter);
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.income_back:
                finish();
                break;
        }
    }
}
