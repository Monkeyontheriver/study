package com.oureda.conquer.Activities.Mine;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.oureda.conquer.R;

//发布项目
public class MakeProjectActivity extends Activity implements View.OnClickListener {
    private Button mp_left_button;
    private Button mp_right_button;
    private static int CONDITION = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_make_project);
        mp_left_button = (Button)findViewById(R.id.mp_left_button);
        mp_right_button = (Button)findViewById(R.id.mp_right_button);
        findViewById(R.id.mp_back).setOnClickListener(this);
        findViewById(R.id.mp_left_button).setOnClickListener(this);
        findViewById(R.id.mp_right_button).setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.mp_back:
                finish();
                break;
            case R.id.mp_left_button:
                if(CONDITION == 1){
                    mp_left_button.setBackgroundColor(getResources().getColor(R.color.tab_top_text_2));
                    mp_left_button.setTextColor(getResources().getColor(R.color.white));
                    mp_right_button.setBackgroundResource(R.drawable.shapelfk);
                    mp_right_button.setTextColor(getResources().getColor(R.color.tab_main_text_1));
                    Log.e("left","button");
                    CONDITION = 0;
                }
                break;
            case R.id.mp_right_button:
                if(CONDITION == 0){
                    mp_right_button.setBackgroundColor(getResources().getColor(R.color.tab_top_text_2));
                    mp_right_button.setTextColor(getResources().getColor(R.color.white));
                    mp_left_button.setBackgroundResource(R.drawable.shapelfk);
                    mp_left_button.setTextColor(getResources().getColor(R.color.tab_main_text_1));
                    Log.e("right", "button");
                    CONDITION = 1;
                }
                break;

        }
    }
}
