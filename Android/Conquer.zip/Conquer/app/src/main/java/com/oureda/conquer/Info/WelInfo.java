package com.oureda.conquer.Info;

/**
 * Created by 刘丰恺 on 2015/8/10.
 */
public class WelInfo {
    private String Wel_Type;
    private String Wel_Title;
    private String Wel_Text;
    public WelInfo(String type,String title,String text){
        this.Wel_Type = type;
        this.Wel_Title = title;
        this.Wel_Text = text;
    }
    public String getWel_Type() {
        return Wel_Type;
    }

    public String getWel_Title() {
        return Wel_Title;
    }

    public String getWel_Text() {
        return Wel_Text;
    }
}
