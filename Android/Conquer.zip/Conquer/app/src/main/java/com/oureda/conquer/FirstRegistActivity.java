package com.oureda.conquer;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;


public class FirstRegistActivity extends Activity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_regist);
        findViewById(R.id.first_regist_back).setOnClickListener(this);
        findViewById(R.id.first_next_button).setOnClickListener(this);
        Intent intent = getIntent();
        if(intent != null){
            String string = "forget";
            Log.e(String.valueOf(intent.getData()),string);
            if(String.valueOf(intent.getData()) == string){
                ((TextView)findViewById(R.id.first_regist_type)).setText("忘记密码");
            }
        }

    }


    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.first_regist_back:
                finish();
                break;
            case R.id.first_next_button:
                Intent regist_second_intent = new Intent(FirstRegistActivity.this,RegistActivity.class);
                startActivity(regist_second_intent);
                break;
        }
    }
}
