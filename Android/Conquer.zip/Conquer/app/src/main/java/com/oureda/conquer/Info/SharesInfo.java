package com.oureda.conquer.Info;

/**
 * Created by 刘丰恺 on 2015/8/8.
 */
public class SharesInfo {
    private String Shares_Name;
    private String Shares_Number;
    private String  Shares_Money;
    private String  Shares_high;
    private String  Shares_low;
    private String Friends;
    private boolean Recent_high;
    private boolean Year_high;

    public SharesInfo(String name,String number,String money,String high,String low,String friends
        ,boolean recent,boolean year){
        Shares_Name = name;
        Shares_Number = number;
        Shares_Money = money;
        Shares_high = high;
        Shares_low = low;
        Friends = friends;
        Recent_high = recent;
        Year_high = year;
    }

    public void setRecent_high(boolean recent_high) {
        Recent_high = recent_high;
    }

    public void setYear_high(boolean year_high) {
        Year_high = year_high;
    }

    public boolean isYear_high() {

        return Year_high;
    }

    public boolean isRecent_high() {
        return Recent_high;
    }

    public void setShares_Name(String shares_Name) {
        Shares_Name = shares_Name;
    }

    public void setShares_Number(String shares_Number) {
        Shares_Number = shares_Number;
    }

    public void setShares_Money(String shares_Money) {
        Shares_Money = shares_Money;
    }

    public void setShares_high(String shares_high) {
        Shares_high = shares_high;
    }

    public void setShares_low(String shares_low) {
        Shares_low = shares_low;
    }

    public void setFriends(String friends) {
        Friends = friends;
    }

    public String getShares_Name() {

        return Shares_Name;
    }

    public String getShares_Number() {
        return Shares_Number;
    }

    public String  getShares_Money() {
        return Shares_Money;
    }

    public String  getShares_high() {
        return Shares_high;
    }

    public String  getShares_low() {
        return Shares_low;
    }

    public String getFriends() {
        return Friends;
    }
}
