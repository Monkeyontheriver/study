package com.oureda.conquer.Activities.Wealth;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

import com.oureda.conquer.Adapter.FriendsAdapter;
import com.oureda.conquer.Info.FriendsInfo;
import com.oureda.conquer.R;

import java.util.ArrayList;

//合伙人
public class ParterActivity extends Activity implements View.OnClickListener{
    private ListView ParterListView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parter);
        findViewById(R.id.parter_back).setOnClickListener(this);
        ParterListView = (ListView)findViewById(R.id.parter_listview);
        ArrayList<FriendsInfo> arrayList = new ArrayList<>();
        arrayList.add(new FriendsInfo(R.drawable.face1,"江竹西","信用值：360"));
        arrayList.add(new FriendsInfo(R.drawable.face2,"常凯申","信用值：360"));
        arrayList.add(new FriendsInfo(R.drawable.face3,"马洛","信用值：360"));
        arrayList.add(new FriendsInfo(R.drawable.face4,"苏秀","信用值：360"));
        arrayList.add(new FriendsInfo(R.drawable.face5,"罗玉文","信用值：360"));
        arrayList.add(new FriendsInfo(R.drawable.face6,"姜文越","信用值：360"));
        arrayList.add(new FriendsInfo(R.drawable.face7,"刘显宗","信用值：360"));
        arrayList.add(new FriendsInfo(R.drawable.face8,"杜玉琴","信用值：360"));
        arrayList.add(new FriendsInfo(R.drawable.face9,"刘璇","信用值：360"));
        FriendsAdapter friendsAdapter = new FriendsAdapter(this,arrayList);
        ParterListView.setAdapter(friendsAdapter);
    }
    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.parter_back:
                finish();
                break;

        }
    }
}
