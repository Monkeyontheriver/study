package com.oureda.conquer.MainFragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;

import com.oureda.conquer.Activities.Mine.AccountLeftActivity;
import com.oureda.conquer.Activities.Mine.HaveMoneyActivity;
import com.oureda.conquer.Activities.Mine.IncomeActivity;
import com.oureda.conquer.Activities.Mine.MineProActivity;
import com.oureda.conquer.Activities.Mine.MineSaleActivity;
import com.oureda.conquer.Activities.Mine.MyAccountActivity;
import com.oureda.conquer.Activities.Mine.MyCreditActivity;
import com.oureda.conquer.Activities.Mine.MyFriendsActivity;
import com.oureda.conquer.Activities.Mine.MyMessageActivity;
import com.oureda.conquer.Activities.Mine.MyWealthActivity;
import com.oureda.conquer.R;
import com.oureda.conquer.Activities.Mine.ScanActivity;


public class MineFragment extends android.support.v4.app.Fragment implements View.OnClickListener{
    private View wrapper;
    private RotateAnimation animation;
    private ImageView Mine_Refresh;
    public static MineFragment newInstance() {
        return new MineFragment();
    }

    public MineFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        this.wrapper = inflater.inflate(R.layout.fragment_mine, container, false);
        wrapper.findViewById(R.id.mine_scan).setOnClickListener(this);
        wrapper.findViewById(R.id.mine_pro).setOnClickListener(this);
        wrapper.findViewById(R.id.mine_sale).setOnClickListener(this);
        wrapper.findViewById(R.id.mine_refresh).setOnClickListener(this);
        wrapper.findViewById(R.id.have_money).setOnClickListener(this);
        wrapper.findViewById(R.id.account_money).setOnClickListener(this);
        wrapper.findViewById(R.id.mine_content_account).setOnClickListener(this);
        wrapper.findViewById(R.id.mine_income).setOnClickListener(this);
        wrapper.findViewById(R.id.mine_my_wealth).setOnClickListener(this);
        wrapper.findViewById(R.id.mine_content_my_credit).setOnClickListener(this);
        wrapper.findViewById(R.id.mine_content_friends).setOnClickListener(this);
        wrapper.findViewById(R.id.mine_content_message).setOnClickListener(this);
        Mine_Refresh = (ImageView)wrapper.findViewById(R.id.mine_refresh);
        animation = new RotateAnimation(0,359,Animation.RELATIVE_TO_SELF,0.5f, Animation.RELATIVE_TO_SELF,0.5f);
        animation.setRepeatCount(0);
        animation.setDuration(2000);
        animation.setFillAfter(true);
        animation.setInterpolator(new LinearInterpolator());
        Mine_Refresh.setAnimation(animation);
        return wrapper;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.mine_scan:
                Intent intent = new Intent(getActivity(), ScanActivity.class);
                getActivity().startActivity(intent);
                break;
            case R.id.mine_pro:
                Intent pro_intent = new Intent(getActivity(), MineProActivity.class);
                getActivity().startActivity(pro_intent);
                break;
            case R.id.mine_sale:
                Intent sale_intent = new Intent(getActivity(), MineSaleActivity.class);
                getActivity().startActivity(sale_intent);
                break;
            case R.id.have_money:
                Intent have_money_intent = new Intent(getActivity(), HaveMoneyActivity.class);
                getActivity().startActivity(have_money_intent);
                break;
            case R.id.account_money:
                Intent account_money_intent = new Intent(getActivity(), AccountLeftActivity.class);
                getActivity().startActivity(account_money_intent);
                break;
            case R.id.mine_refresh:
                Mine_Refresh.startAnimation(animation);
                break;
            case R.id.mine_content_account:
                Intent mine_account_intent = new Intent(getActivity(), MyAccountActivity.class);
                getActivity().startActivity(mine_account_intent);
                break;
            case R.id.mine_income:
                Intent mine_income_intent = new Intent(getActivity(), IncomeActivity.class);
                getActivity().startActivity(mine_income_intent);
                break;
            case R.id.mine_my_wealth:
                Intent mine_my_wealth_intent = new Intent(getActivity(), MyWealthActivity.class);
                getActivity().startActivity(mine_my_wealth_intent);
                break;
            case R.id.mine_content_my_credit:
                Intent mine_my_credit_intent = new Intent(getActivity(), MyCreditActivity.class);
                getActivity().startActivity(mine_my_credit_intent);
                break;
            case R.id.mine_content_friends:
                Intent mine_my_friends_intent = new Intent(getActivity(), MyFriendsActivity.class);
                getActivity().startActivity(mine_my_friends_intent);
                break;
            case R.id.mine_content_message:
                Intent mine_my_message_intent = new Intent(getActivity(), MyMessageActivity.class);
                getActivity().startActivity(mine_my_message_intent);
                break;
        }
    }
}
