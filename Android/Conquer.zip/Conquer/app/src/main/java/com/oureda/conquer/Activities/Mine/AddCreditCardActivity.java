package com.oureda.conquer.Activities.Mine;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.oureda.conquer.R;

//添加银行卡
public class AddCreditCardActivity extends Activity implements View.OnClickListener{
    private static int BANK_CHOOSE = 0;
    private EditText credit_id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_credit_card);
        findViewById(R.id.add_creditcard_back).setOnClickListener(this);
        findViewById(R.id.add_credit_card_bankchoose).setOnClickListener(this);
        findViewById(R.id.clear_credit_id).setOnClickListener(this);
        credit_id = (EditText)findViewById(R.id.credit_id);
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.add_creditcard_back:
                finish();
                break;
            case R.id.add_credit_card_bankchoose:
                Intent intent_bank_choose = new Intent(AddCreditCardActivity.this,BankChooseActivity.class);
                startActivityForResult(intent_bank_choose, BANK_CHOOSE);
                break;
            case R.id.clear_credit_id:
                credit_id.setText("");
                break;

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == BANK_CHOOSE){
            ((TextView)findViewById(R.id.add_credit_card_bankname)).setText(data.getStringExtra("bank"));
        }
    }
}
