package com.oureda.conquer.Activities.Education;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.oureda.conquer.R;

//咨询子页面
public class WelContentActivity extends Activity implements View.OnClickListener{
    private TextView Wel_Text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wel_content);
        Intent intent = getIntent();
        if(intent != null){
            TextView Wel_Title = (TextView)findViewById(R.id.wel_content_title);
            Wel_Title.setText(intent.getStringExtra("wel_title"));
            Wel_Text = (TextView)findViewById(R.id.wel_content_text);
            Wel_Text.setText(intent.getStringExtra("wel_text"));
        }
        findViewById(R.id.wel_content_back).setOnClickListener(this);
        findViewById(R.id.wel_content_share).setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.wel_content_back:
                finish();
                break;
            case R.id.wel_content_share:
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_SEND);
                intent.putExtra(Intent.EXTRA_TEXT, Wel_Text.getText().toString());
                intent.setType("text/plain");
                startActivity(Intent.createChooser(intent, "文章分享"));
                break;
        }
    }
}
