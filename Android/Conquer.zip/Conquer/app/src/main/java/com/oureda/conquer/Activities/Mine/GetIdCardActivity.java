package com.oureda.conquer.Activities.Mine;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.oureda.conquer.R;

//验证身份证
public class GetIdCardActivity extends Activity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_id_card);
        findViewById(R.id.get_id_next).setOnClickListener(this);
        findViewById(R.id.get_idcard_back).setOnClickListener(this);

    }


    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.get_id_next:
                Intent intent = new Intent(GetIdCardActivity.this,AddCreditCardActivity.class);
                startActivity(intent);
                break;
            case R.id.get_idcard_back:
                finish();
                break;
        }
    }
}
