package com.oureda.conquer.Activities.Mine;

import android.app.Activity;
import android.content.Intent;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.graphics.Rect;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.github.yoojia.zxing.QRCodeEncode;
import com.oureda.conquer.R;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

//生成二维码
public class ShowMineActivity extends Activity implements View.OnClickListener{
    private ImageView mQRCodeImage;
    private QRCodeEncode mEncoder;
    private DecodeTask mDecodeTask;
    private Intent sendIntent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_mine);
        mQRCodeImage = (ImageView)findViewById(R.id.qrcode_image);
        final WindowManager manager = (WindowManager) getSystemService(WINDOW_SERVICE);
        final Display display = manager.getDefaultDisplay();
        Point displaySize = new Point();
        display.getSize(displaySize);
        final int width = displaySize.x;
        final int height = displaySize.y;
        final int dimension = width < height ? width : height;
        mEncoder = new QRCodeEncode.Builder()
                .setBackgroundColor(0xFFFFFF)
                .setCodeColor(0XFFFA5050)
                .setOutputBitmapPadding(2)
                .setOutputBitmapWidth(dimension)
                .setOutputBitmapHeight(dimension)
                .build();
        mDecodeTask = new DecodeTask();
        mDecodeTask.execute("刘丰恺");
        findViewById(R.id.show_back).setOnClickListener(this);
        findViewById(R.id.show_share).setOnClickListener(this);
    }
    private void setmShareActionProvider(){
        sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_STREAM, shotit());
        sendIntent.setType("image/jpeg");
    }
    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.show_back:
                finish();
                break;
            case R.id.show_share:
                Log.e("分享","分享");
                setmShareActionProvider();
                startActivity(Intent.createChooser(sendIntent, "二维码分享"));
                break;
        }
    }

    private class DecodeTask extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... params) {
            return mEncoder.encode(params[0]);
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            mQRCodeImage.setImageBitmap(bitmap);
        }
    }

    private Uri shotit() {
        View view = getWindow().getDecorView();
        Display display = this.getWindowManager().getDefaultDisplay();
        view.layout(0, 0, display.getWidth(), display.getHeight());
        view.setDrawingCacheEnabled(true);//允许当前窗口保存缓存信息，这样getDrawingCache()方法才会返回一个Bitmap
        Rect frame = new Rect();
        this.getWindow().getDecorView().getWindowVisibleDisplayFrame(frame);
        int statusBarHeight = frame.top;
        // 获取屏幕长和高
        int width = this.getWindowManager().getDefaultDisplay().getWidth();
        int height = this.getWindowManager().getDefaultDisplay()
                .getHeight();
        TypedArray actionbarSizeTypedArray = this.obtainStyledAttributes(new int[]{
                android.R.attr.actionBarSize});
        int h = (int)actionbarSizeTypedArray.getDimension(0, 0);
        RelativeLayout r = (RelativeLayout)findViewById(R.id.share_layout);
        int r_height = r.getHeight();
        int r_width = r.getWidth();
        Bitmap bmp = Bitmap.createBitmap(view.getDrawingCache(),dip2px(30), statusBarHeight + h + dip2px(60),
                r_width, r_height);
        File f = new File(Environment.getExternalStorageDirectory(),
                "output_image.jpg");
        FileOutputStream fOut = null;
        try {
            fOut = new FileOutputStream(f);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
        try {
            assert fOut != null;
            fOut.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            fOut.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return Uri.fromFile(f);
    }
    public int px2dip(float pxValue) {
        final float scale = this.getResources().getDisplayMetrics().density;
        return (int) (pxValue / scale + 0.5f);
    }
    public int dip2px(float dpValue) {
        final float scale = this.getResources().getDisplayMetrics().density;
        return (int) (dpValue * scale + 0.5f);
    }
}
