package com.oureda.conquer;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;


public class OpenActivity extends Activity {
    private View Open_View;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Open_View = View.inflate(this,R.layout.activity_open,null);
        setContentView(Open_View);
        AlphaAnimation start = new AlphaAnimation(0.3f,1.0f);
        start.setDuration(2000);
        Open_View.startAnimation(start);
        start.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationEnd(Animation arg0) {
                Log.e("linc", "---start!");
                try {
                    Intent intent = new Intent(OpenActivity.this, LoginActivity.class);
                    startActivity(intent);
                    Open_View = null;
                    finish();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationStart(Animation animation) {
            }
        });


    }

}
