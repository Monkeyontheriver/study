package com.oureda.conquer.Info;

/**
 * Created by 刘丰恺 on 2015/8/14.
 */
public class FriendsInfo {
    private int Friends_Img;
    private String Friends_Name;
    private String Friends_Cridet;

    public FriendsInfo(int friends_Img, String friends_Name, String friends_Cridet) {
        Friends_Img = friends_Img;
        Friends_Name = friends_Name;
        Friends_Cridet = friends_Cridet;
    }

    public int getFriends_Img() {
        return Friends_Img;
    }

    public String getFriends_Name() {
        return Friends_Name;
    }

    public String getFriends_Cridet() {
        return Friends_Cridet;
    }
}
