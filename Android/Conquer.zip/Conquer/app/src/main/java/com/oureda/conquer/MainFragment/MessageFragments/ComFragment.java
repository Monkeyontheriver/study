package com.oureda.conquer.MainFragment.MessageFragments;


import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.oureda.conquer.Adapter.ComAdapter;
import com.oureda.conquer.Info.ComLinfo;
import com.oureda.conquer.R;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class ComFragment extends android.support.v4.app.Fragment {
    private View wrapper;
    public static ComFragment newInstance(){
        return new ComFragment();
    }

    public ComFragment() {
        // Required empty public constructor
    }
//    (int img,String id,String project,String dowhat,String time,String first,
//    String ftype,String second,String stype,String third,String thtype)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        this.wrapper =  inflater.inflate(R.layout.fragment_com, container, false);
        ListView Com_ListView = (ListView)wrapper.findViewById(R.id.com_listview);
        ArrayList<ComLinfo> arrayList = new ArrayList<>();
        arrayList.add(new ComLinfo(R.drawable.face1,"曹升杨","中邮战略新兴产业股票型证券",
                "发布项目","今天 22:16","8000","总金额（元）","15","还款期限（天）","4.03","年利率（%）"));
        arrayList.add(new ComLinfo(R.drawable.face2,"董文静","中邮战略新兴产业股票型证券",
                "发布项目","今天 22:16","8000","总金额（元）","15","还款期限（天）","4.03","年利率（%）"));
        arrayList.add(new ComLinfo(R.drawable.face3,"杜加运","中邮战略新兴产业股票型证券",
                "发布项目","今天 22:16","8000","总金额（元）","15","还款期限（天）","4.03","年利率（%）"));
        arrayList.add(new ComLinfo(R.drawable.face4,"李明泽","中邮战略新兴产业股票型证券",
                "发布项目","今天 22:16","8000","总金额（元）","15","还款期限（天）","4.03","年利率（%）"));
        arrayList.add(new ComLinfo(R.drawable.face5,"常凯申","中邮战略新兴产业股票型证券",
                "发布项目","今天 22:16","8000","总金额（元）","15","还款期限（天）","4.03","年利率（%）"));
        arrayList.add(new ComLinfo(R.drawable.face6,"李德生","中邮战略新兴产业股票型证券",
                "发布项目","今天 22:16","8000","总金额（元）","15","还款期限（天）","4.03","年利率（%）"));
        arrayList.add(new ComLinfo(R.drawable.face7,"李京文","中邮战略新兴产业股票型证券",
                "发布项目","今天 22:16","8000","总金额（元）","15","还款期限（天）","4.03","年利率（%）"));
        arrayList.add(new ComLinfo(R.drawable.face8,"冉冉","中邮战略新兴产业股票型证券",
                "发布项目","今天 22:16","8000","总金额（元）","15","还款期限（天）","4.03","年利率（%）"));
        ComAdapter comAdapter = new ComAdapter(getActivity(),arrayList);
        Com_ListView.setAdapter(comAdapter);
        Com_ListView.setVerticalScrollBarEnabled(true);
        return wrapper;
    }


}
