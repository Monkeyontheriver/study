package com.oureda.conquer.Activities.Wealth;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;

import com.oureda.conquer.R;
import com.oureda.conquer.UI.DialPlateView;

import java.util.Timer;
import java.util.TimerTask;

public class SharesContentFront extends Activity implements View.OnClickListener{
    private DialPlateView dialplate;
    private int index = 0;
    private Timer timer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shares_content_front);
        dialplate = (DialPlateView) findViewById(R.id.front_dialplate);
        dialplate.setMin(0);
        dialplate.setMax(100);
        dialplate.setProgressColorStatus(true);
        dialplate.setBackgroundColor(Color.WHITE);
        dialplate.setTextJudge("风险投资");
        dialplate.setTextJudgeTime("评估时间：2015.7.22");
        dialplate.setJudgeTimeColor(Color.parseColor("#acacac"));
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        index += 10;
                        dialplate.setProgress(index);
                    }
                });
            }
        }, 1000, 16);
        findViewById(R.id.front_back).setOnClickListener(this);
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.front_back:
                finish();
                break;
        }
    }
}
