package com.oureda.conquer.Activities.Message;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

import com.oureda.conquer.R;

//售卖子页面
public class SaleContentActivity extends Activity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sale_content);
        findViewById(R.id.sale_content_back).setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.sale_content_back:
                finish();
                break;
        }
    }
}
