package com.oureda.conquer.Activities.Mine;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.oureda.conquer.LoginActivity;
import com.oureda.conquer.R;
import com.oureda.conquer.RegistActivity;

//我的账户
public class MyAccountActivity extends Activity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_account);
        findViewById(R.id.my_account_back).setOnClickListener(this);
        findViewById(R.id.my_account_account).setOnClickListener(this);
        findViewById(R.id.my_account_bank).setOnClickListener(this);
        findViewById(R.id.my_account_change).setOnClickListener(this);
        findViewById(R.id.my_account_change_password).setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.my_account_back:
                finish();
                break;
            case R.id.my_account_account:
                Intent intent = new Intent(MyAccountActivity.this,GetIdCardActivity.class);
                startActivity(intent);
                break;
            case R.id.my_account_bank:
                Intent my_bank_intent = new Intent(MyAccountActivity.this,BankChooseActivity.class);
                startActivity(my_bank_intent);
                break;
            case R.id.my_account_change:
                Intent my_change_intent = new Intent(MyAccountActivity.this,LoginActivity.class);
                startActivity(my_change_intent);
                finish();
                break;
            case R.id.my_account_change_password:
                Intent my_change_password_intent = new Intent(MyAccountActivity.this, RegistActivity.class);
                startActivity(my_change_password_intent);
                finish();
                break;
        }
    }
}
