package com.oureda.conquer.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.oureda.conquer.Info.BankInfo;
import com.oureda.conquer.R;

import java.util.ArrayList;

/**
 * Created by 刘丰恺 on 2015/8/13.
 */
public class BankAdapter extends BaseAdapter {
    private LayoutInflater layoutInflater;
    private Context context;
    private ArrayList<BankInfo> userlist;

    public BankAdapter(Context context,ArrayList<BankInfo> arrayList){
        this.context = context;
        this.layoutInflater = LayoutInflater.from(context);
        this.userlist = arrayList;
    }

    private class BankListView{
        private ImageView Bank_Img;
        private TextView Bank_Title;
        private TextView Bank_Text;
    }

    @Override
    public int getCount() {
        return userlist.size();
    }

    @Override
    public Object getItem(int i) {
        return userlist.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        BankListView bankListView = null;
        if(view == null){
            bankListView = new BankListView();
            view = layoutInflater.inflate(R.layout.bank_list_item,null);
            bankListView.Bank_Img = (ImageView)view.findViewById(R.id.bank_img);
            bankListView.Bank_Title = (TextView)view.findViewById(R.id.bank_title);
            bankListView.Bank_Text = (TextView)view.findViewById(R.id.bank_text);
            view.setTag(bankListView);
        }else {
            bankListView = (BankListView)view.getTag();
        }
        BankInfo bankInfo = userlist.get(i);
        bankListView.Bank_Img.setImageResource(bankInfo.getBank_img());
        bankListView.Bank_Title.setText(bankInfo.getBank_Title());
        bankListView.Bank_Text.setText(bankInfo.getBank_Text());
        return view;
    }
}
