package com.oureda.conquer;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.oureda.conquer.MainFragment.EduFragment;
import com.oureda.conquer.MainFragment.MessageFragment;
import com.oureda.conquer.MainFragment.MineFragment;
import com.oureda.conquer.MainFragment.MoneyFragment;
import com.shizhefei.view.indicator.Indicator;
import com.shizhefei.view.indicator.IndicatorViewPager;


public class MainActivity extends FragmentActivity {
    private ViewPager viewPager;
    private Indicator indicator;
    private IndicatorViewPager indicatorViewPager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        viewPager = (ViewPager)findViewById(R.id.viewpager);
        indicator = (Indicator) findViewById(R.id.tabmain_indicator);
        indicatorViewPager = new IndicatorViewPager(indicator, viewPager);
        indicatorViewPager.setAdapter(new MainAdapter(getSupportFragmentManager()));
        viewPager.setCanScroll(false);
        viewPager.setOffscreenPageLimit(4);
        viewPager.setPrepareNumber(0);
    }

    public class MainAdapter extends IndicatorViewPager.IndicatorFragmentPagerAdapter {
        private String[] tabNames = { "实时财富", "理财教育", "消息广场", "我的财富" };
        private int[] tabIcons = { R.drawable.icon_weath_selector, R.drawable.icon_edu_selector, R.drawable.icon_message_selector,
                R.drawable.icon_mine_selector };
        private LayoutInflater inflater;

        public MainAdapter(FragmentManager fragmentManager) {
            super(fragmentManager);
            inflater = LayoutInflater.from(getApplicationContext());
        }


        @Override
        public int getCount() {
            return tabNames.length;
        }

        @Override
        public View getViewForTab(int position, View convertView, ViewGroup container) {
            if (convertView == null) {
                convertView = inflater.inflate(R.layout.tab_main, container, false);
            }
            TextView textView = (TextView) convertView.findViewById(R.id.tab_main_text);
            textView.setText(tabNames[position]);
            ImageView imageView = (ImageView)convertView.findViewById(R.id.tab_main_img);
            imageView.setImageResource(tabIcons[position]);
            return convertView;
        }

        @Override
        public android.support.v4.app.Fragment getFragmentForPage(int position) {
            android.support.v4.app.Fragment fragment = null;
            switch(position){
                case 0:
                    fragment = MoneyFragment.newInstance();
                    break;
                case 1:
                    fragment = EduFragment.newInstance();
                    break;
                case 2:
                    fragment = MessageFragment.newInstance();
                    break;
                case 3:
                    fragment = MineFragment.newInstance();
                    break;
            }
            return fragment;
        }

    }

}
