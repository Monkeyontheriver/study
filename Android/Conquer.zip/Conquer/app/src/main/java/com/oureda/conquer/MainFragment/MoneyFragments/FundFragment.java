package com.oureda.conquer.MainFragment.MoneyFragments;


import android.app.Fragment;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.oureda.conquer.MainFragment.ChartsFragment;
import com.oureda.conquer.R;
import com.shizhefei.view.indicator.Indicator;
import com.shizhefei.view.indicator.IndicatorViewPager;
import com.shizhefei.view.indicator.slidebar.LayoutBar;
import com.shizhefei.view.indicator.slidebar.ScrollBar;
import com.shizhefei.view.indicator.transition.OnTransitionTextListener;

/**
 * A simple {@link Fragment} subclass.
 */
public class FundFragment extends android.support.v4.app.Fragment {
    private View wrapper;
    private ViewPager FundViewPager;
    private IndicatorViewPager indicatorViewPager;
    private LayoutInflater inflate;
    private int number;
    public FundFragment() {
        // Required empty public constructor
    }

    public FundFragment(int number){
        Log.e("numbers",""+number);
        this.number = number;
    }
    public static FundFragment newInstance(int number){
        Log.e("numbers",""+number);

        return new FundFragment(number);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        this.wrapper =  inflater.inflate(R.layout.fragment_fund, container, false);
        FundViewPager = (ViewPager)wrapper.findViewById(R.id.fund_viewpager);
        Indicator indicator = (Indicator) wrapper.findViewById(R.id.fund_indicator);
        indicator.setScrollBar(new LayoutBar(getActivity().getApplicationContext(), R.layout.layout_slidebar, ScrollBar.Gravity.CENTENT_BACKGROUND));
        Resources res = getResources();
        float unSelectSize = 16;
        float selectSize = unSelectSize * 1.0f;
        int selectColor = res.getColor(R.color.tab_top_text_2);
        int unSelectColor = res.getColor(R.color.tab_top_text_1);
        indicator.setOnTransitionListener(new OnTransitionTextListener().setColor(selectColor, unSelectColor).setSize(selectSize, unSelectSize));
        FundViewPager.setOffscreenPageLimit(5);
        FundViewPager.setCanScroll(false);
        FundViewPager.setPrepareNumber(0);
        indicatorViewPager = new IndicatorViewPager(indicator, FundViewPager);
        inflate = LayoutInflater.from(getActivity().getApplicationContext());
        indicatorViewPager.setAdapter(new EduAdapter(getFragmentManager(),inflate));
        return wrapper;
    }
    private class EduAdapter extends IndicatorViewPager.IndicatorFragmentPagerAdapter {
        private String[] tabName = {"每星期","每月","每两个月","每季度","每学期"};
        private LayoutInflater inflater;
        public EduAdapter(FragmentManager fragmentManager,LayoutInflater inflater) {
            super(fragmentManager);
            this.inflater = inflater;
        }

        @Override
        public int getCount() {
            return tabName.length;
        }

        @Override
        public View getViewForTab(int position, View convertView, ViewGroup container) {
            if (convertView == null) {
                convertView = inflater.inflate(R.layout.top_padding, container, false);
            }
            TextView textView = (TextView) convertView;
            textView.setText(tabName[position]);
            return textView;
        }

        @Override
        public android.support.v4.app.Fragment getFragmentForPage(int position) {
            android.support.v4.app.Fragment fragment = null;
            if(position == 0){
                fragment = ChartsFragment.newInstance(number);
            }
            else fragment = OthersFragment.newInstance();
            return fragment;
        }
    }

}
