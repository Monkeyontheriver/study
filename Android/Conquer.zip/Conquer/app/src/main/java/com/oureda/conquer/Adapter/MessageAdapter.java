package com.oureda.conquer.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.oureda.conquer.Info.MessageInfo;
import com.oureda.conquer.R;

import java.util.ArrayList;

/**
 * Created by liufengkai on 15/9/7.
 */
public class MessageAdapter extends BaseAdapter {
    private Context context;
    private LayoutInflater layoutInflater;
    private ArrayList<MessageInfo> userList;

    private class MessageListView{
        private TextView message_pro;
        private ImageView message_img;
        private TextView message_time;
        private TextView message_what;
        private TextView message_name;
    }

    public MessageAdapter(Context context, ArrayList<MessageInfo> userList) {
        this.context = context;
        this.userList = userList;
        this.layoutInflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return userList.size();
    }

    @Override
    public Object getItem(int position) {
        return userList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        MessageListView messageListView = null;
        if(convertView == null){
            messageListView = new MessageListView();
            convertView = layoutInflater.inflate(R.layout.message_item,null);
            messageListView.message_img = (ImageView) convertView.findViewById(R.id.message_img);
            messageListView.message_name = (TextView) convertView.findViewById(R.id.message_name);
            messageListView.message_pro = (TextView) convertView.findViewById(R.id.message_pro);
            messageListView.message_time = (TextView) convertView.findViewById(R.id.message_time);
            messageListView.message_what = (TextView) convertView.findViewById(R.id.message_what);
            convertView.setTag(messageListView);
        }else {
            messageListView = (MessageListView) convertView.getTag();
        }
        MessageInfo messageInfo = userList.get(position);
        messageListView.message_img.setImageResource(messageInfo.getMessage_img());
        messageListView.message_name.setText(messageInfo.getMessage_name());
        messageListView.message_what.setText(messageInfo.getMessage_what());
        messageListView.message_time.setText(messageInfo.getMessage_time());
        messageListView.message_pro.setText(messageInfo.getMessage_pro());
        messageListView.message_name.setTextColor(messageInfo.getMessage_color());
        return convertView;
    }
}
