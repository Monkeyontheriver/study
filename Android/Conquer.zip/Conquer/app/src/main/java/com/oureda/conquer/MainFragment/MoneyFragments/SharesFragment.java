package com.oureda.conquer.MainFragment.MoneyFragments;

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.oureda.conquer.Adapter.SharesAdapter;
import com.oureda.conquer.Info.SharesInfo;
import com.oureda.conquer.R;
import com.oureda.conquer.Activities.Wealth.SharesConentActivity;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class SharesFragment extends android.support.v4.app.Fragment {
    private View wrapper;
    private ListView SharesListView;
    private SharesAdapter sharesAdapter;
    private int type;
    public SharesFragment(int type) {
        this.type = type;
    }

    public SharesFragment(){

    }
    public static SharesFragment newInstance(int type){
        return new SharesFragment(type);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        this.wrapper = inflater.inflate(R.layout.fragment_shares, container, false);
        SharesListView = (ListView)wrapper.findViewById(R.id.shares_listview);
        sharesAdapter = new SharesAdapter(getActivity(),WealthType(type));
        SharesListView.setAdapter(sharesAdapter);

        SharesListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getActivity(), SharesConentActivity.class);
                intent.putExtra("shares_type", type + "");
                intent.putExtra("shares_name", ((TextView) view.findViewById(R.id.shares_name)).getText());
                intent.putExtra("shares_number", ((TextView) view.findViewById(R.id.shares_number)).getText());
                intent.putExtra("shares_low", ((TextView) view.findViewById(R.id.shares_low)).getText());
                intent.putExtra("shares_high", ((TextView) view.findViewById(R.id.shares_high)).getText());
                intent.putExtra("shares_money", ((TextView) view.findViewById(R.id.shares_money)).getText());
                getActivity().startActivity(intent);
            }
        });
        SharesListView.setVerticalScrollBarEnabled(true);
        return wrapper;
    }
    private ArrayList<SharesInfo> WealthType(int type){
        //换成不一样类型的
        ArrayList<SharesInfo> arrayList = new ArrayList<>();
        switch (type){
            case 0:{
                arrayList.add(new SharesInfo("北京文化","000802","090","88","3.676","刘丰恺",true,false));
                arrayList.add(new SharesInfo("四川长虹","600989","090","88","3.676","刘丰恺",true,true));
                arrayList.add(new SharesInfo("大秦铁路","678332","090","88","3.676","刘丰恺",true,true));
                arrayList.add(new SharesInfo("大众公用","600635","090","88","3.676","刘丰恺",true,true));
                arrayList.add(new SharesInfo("大众交通","123434","090","88","3.676","刘丰恺",true,true));
                arrayList.add(new SharesInfo("浙能电力","457845","090","88","3.676","刘丰恺",true,true));
                break;
            }
            case 1:{
                arrayList.add(new SharesInfo("南方基金","848583","090","88","3.676","刘丰恺",true,false));
                arrayList.add(new SharesInfo("中欧明锐","352545","090","88","3.676","刘丰恺",true,true));
                arrayList.add(new SharesInfo("易方达安心回报债券A","464646","090","88","3.676","刘丰恺",true,false));
                arrayList.add(new SharesInfo("华商创新成长混合发起式","464646","090","88","3.676","刘丰恺",true,true));
                arrayList.add(new SharesInfo("华商价值精选混合","214124","090","88","3.676","刘丰恺",true,false));
                arrayList.add(new SharesInfo("易方达安心回报债券B","122422","090","88","3.676","刘丰恺",true,false));
                break;
            }
            case 2:{
                arrayList.add(new SharesInfo("中安信业 - 薪贷","464646","090","88","3.676","lfk",true,false));
                arrayList.add(new SharesInfo("拍拍贷 - 拍拍贷","435466","090","88","3.676","lfk",true,true));
                arrayList.add(new SharesInfo("拍拍贷 - 私营业主贷","254646","090","88","3.676","lfk",true,true));
                arrayList.add(new SharesInfo("拍拍贷 - 学生贷","576879","090","88","3.676","lfk",true,true));
                arrayList.add(new SharesInfo("中安信业 - E时贷","565656","090","88","3.676","lfk",true,true));
                arrayList.add(new SharesInfo("拍拍贷 - 网商贷","578979","090","88","3.676","lfk",true,true));
                break;
            }
        }
        return arrayList;
    }

}
