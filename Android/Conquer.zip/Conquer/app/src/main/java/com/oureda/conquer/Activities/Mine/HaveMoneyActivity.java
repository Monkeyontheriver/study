package com.oureda.conquer.Activities.Mine;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;

import com.oureda.conquer.R;

//持有资金
public class HaveMoneyActivity extends Activity implements OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_have_money);
        findViewById(R.id.have_money_back).setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.have_money_back:
                finish();
                break;
        }
    }
}
